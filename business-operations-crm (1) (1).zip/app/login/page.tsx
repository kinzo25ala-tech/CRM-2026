import { redirect } from "next/navigation"
import { Radar } from "lucide-react"
import { getSession } from "@/lib/auth/session"
import { LoginForm } from "@/components/crm/login-form"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export const metadata = {
  title: "تسجيل الدخول | نظام إدارة الطلبات",
  description: "تسجيل الدخول إلى نظام إدارة الطلبات المرتبط بـ Google Sheets",
}

export default async function LoginPage() {
  const session = await getSession()
  if (session) redirect("/dashboard")

  return (
    <div dir="rtl" className="flex min-h-screen items-center justify-center bg-background px-4 py-10">
      <div className="w-full max-w-sm">
        <div className="mb-6 flex flex-col items-center gap-2 text-center">
          <div className="flex size-11 items-center justify-center rounded-lg bg-primary/15">
            <Radar className="size-5 text-primary" aria-hidden="true" />
          </div>
          <h1 className="text-lg font-semibold text-foreground">نظام إدارة الطلبات</h1>
          <p className="text-sm text-muted-foreground">سجل الدخول لإدارة طلباتك وتأكيدها وشحنها</p>
        </div>
        <Card className="border-border">
          <CardHeader>
            <CardTitle className="text-base">تسجيل الدخول</CardTitle>
            <CardDescription>استخدم بيانات حسابك في النظام</CardDescription>
          </CardHeader>
          <CardContent>
            <LoginForm />
            <p className="mt-4 text-center text-xs text-muted-foreground">
              حساب تجريبي: admin / admin123 (المالك) أو agent / agent123 (موظف تأكيد)
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
