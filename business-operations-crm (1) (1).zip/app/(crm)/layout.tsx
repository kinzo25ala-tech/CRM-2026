import type { ReactNode } from "react"
import { requireSessionOrRedirect } from "@/lib/auth/require-session"
import { CrmShell } from "@/components/crm/crm-shell"
import { getSettings } from "@/lib/services/settings-service"

export default async function CrmLayout({ children }: { children: ReactNode }) {
  const session = await requireSessionOrRedirect()
  const settings = await getSettings()

  return (
    <CrmShell session={session} businessName={settings.businessName || "نظام إدارة الطلبات"}>
      {children}
    </CrmShell>
  )
}
