import { requirePermissionOrRedirect } from "@/lib/auth/require-session"
import { getSettings } from "@/lib/services/settings-service"
import { GeneralSettingsForm } from "@/components/crm/settings/general-settings-form"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default async function GeneralSettingsPage() {
  await requirePermissionOrRedirect("settings.view")
  const settings = await getSettings()

  return (
    <Card className="max-w-xl border-border">
      <CardHeader>
        <CardTitle className="text-base">إعدادات العمل العامة</CardTitle>
      </CardHeader>
      <CardContent>
        <GeneralSettingsForm settings={settings} />
      </CardContent>
    </Card>
  )
}
