import type { ReactNode } from "react"
import Link from "next/link"
import { requireSessionOrRedirect } from "@/lib/auth/require-session"
import { roleHasPermission } from "@/lib/auth/permissions"

const SETTINGS_TABS = [
  { href: "/settings", label: "عام", permission: "settings.view" as const },
  { href: "/settings/data-sources", label: "مصادر البيانات", permission: "settings.datasources.manage" as const },
  { href: "/settings/users", label: "المستخدمون", permission: "settings.users.manage" as const },
  { href: "/settings/tiktok", label: "تيك توك", permission: "settings.tiktok.manage" as const },
  { href: "/settings/audit", label: "سجل التدقيق", permission: "settings.audit.view" as const },
]

export default async function SettingsLayout({ children }: { children: ReactNode }) {
  const session = await requireSessionOrRedirect()
  const tabs = SETTINGS_TABS.filter((t) => roleHasPermission(session.role, t.permission))

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-xl font-semibold text-foreground">الإعدادات</h1>
        <p className="text-sm text-muted-foreground">إدارة المستخدمين، مصادر البيانات، والتكاملات</p>
      </div>
      <nav className="flex flex-wrap gap-1 border-b border-border">
        {tabs.map((tab) => (
          <Link
            key={tab.href}
            href={tab.href}
            className="rounded-t-md px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
          >
            {tab.label}
          </Link>
        ))}
      </nav>
      <div>{children}</div>
    </div>
  )
}
