import {
  ShoppingCart,
  PhoneCall,
  CheckCircle2,
  XCircle,
  Truck,
  PackageCheck,
  Undo2,
  Clock,
} from "lucide-react"
import { getDashboardData, type DateRangeKey } from "@/lib/services/reports-service"
import { requirePermissionOrRedirect } from "@/lib/auth/require-session"
import { StatCard } from "@/components/crm/stat-card"
import { DashboardRangeFilter } from "@/components/crm/dashboard-range-filter"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ORDER_STATUS_LABELS_AR, type OrderStatus } from "@/lib/domain/types"
import { isUsingRealSheet } from "@/lib/data/repository-provider"

function formatDzd(n: number | null): string {
  if (n == null) return "غير متوفر"
  return `${n.toLocaleString("ar-DZ")} د.ج`
}

function formatPct(n: number): string {
  return `${Math.round(n * 100)}%`
}

export default async function DashboardPage({
  searchParams,
}: {
  searchParams: Promise<{ range?: string }>
}) {
  await requirePermissionOrRedirect("dashboard.view")
  const { range } = await searchParams
  const rangeKey = (range as DateRangeKey) || "all"
  const data = await getDashboardData(rangeKey)
  const usingRealSheet = await isUsingRealSheet()

  const statusOrder: OrderStatus[] = [
    "NEW",
    "PENDING_CONFIRMATION",
    "CALLED",
    "CONFIRMED",
    "POSTPONED",
    "CANCELLED",
    "READY_TO_SHIP",
    "SHIPPED",
    "IN_TRANSIT",
    "DELIVERED",
    "RETURNED",
  ]

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-semibold text-foreground">لوحة التحكم</h1>
          <p className="text-sm text-muted-foreground">
            {usingRealSheet ? "البيانات من Google Sheets المرتبط" : "بيانات تجريبية محلية — لم يتم ربط Google Sheets بعد"}
          </p>
        </div>
        <DashboardRangeFilter current={rangeKey} />
      </div>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
        <StatCard label="إجمالي الطلبات" value={String(data.total)} icon={<ShoppingCart className="size-4" />} tone="primary" />
        <StatCard label="في انتظار التأكيد" value={String(data.statusCounts.PENDING_CONFIRMATION ?? 0)} icon={<Clock className="size-4" />} tone="warning" />
        <StatCard label="تم الاتصال" value={String(data.statusCounts.CALLED ?? 0)} icon={<PhoneCall className="size-4" />} />
        <StatCard label="مؤكد" value={String(data.statusCounts.CONFIRMED ?? 0)} icon={<CheckCircle2 className="size-4" />} tone="success" />
        <StatCard label="ملغى" value={String(data.statusCounts.CANCELLED ?? 0)} icon={<XCircle className="size-4" />} tone="danger" />
        <StatCard label="تم الشحن" value={String(data.statusCounts.SHIPPED ?? 0)} icon={<Truck className="size-4" />} />
        <StatCard label="مسلم" value={String(data.statusCounts.DELIVERED ?? 0)} icon={<PackageCheck className="size-4" />} tone="success" />
        <StatCard label="مرتجع" value={String(data.statusCounts.RETURNED ?? 0)} icon={<Undo2 className="size-4" />} tone="danger" />
      </div>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="نسبة التأكيد" value={formatPct(data.kpis.confirmationRate)} tone="primary" />
        <StatCard label="نسبة الإلغاء" value={formatPct(data.kpis.cancellationRate)} tone="danger" />
        <StatCard label="نسبة التسليم" value={formatPct(data.kpis.deliveryRate)} tone="success" />
        <StatCard label="نسبة المرتجع" value={formatPct(data.kpis.returnRate)} tone="warning" />
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card className="border-border">
          <CardHeader>
            <CardTitle className="text-base">نظرة مالية</CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-2 gap-4 text-sm">
            <FinancialRow label="إجمالي قيمة الطلبات" value={formatDzd(data.financial.revenue)} />
            <FinancialRow label="قيمة الطلبات المؤكدة" value={formatDzd(data.financial.confirmedRevenue)} />
            <FinancialRow label="قيمة الطلبات المسلمة" value={formatDzd(data.financial.deliveredRevenue)} />
            <FinancialRow label="تكلفة المنتجات" value={formatDzd(data.financial.productCost)} />
            <FinancialRow label="تكلفة التوصيل" value={formatDzd(data.financial.shippingCost)} />
            <FinancialRow label="مصروفات الإعلان" value={formatDzd(data.financial.advertisingCost)} />
            <FinancialRow label="الربح الإجمالي التقديري" value={formatDzd(data.financial.estimatedGrossResult)} emphasize />
            <FinancialRow label="الربح الصافي التقديري" value={formatDzd(data.financial.estimatedNetResult)} emphasize />
          </CardContent>
        </Card>

        <Card className="border-border">
          <CardHeader>
            <CardTitle className="text-base">توزيع الطلبات حسب الحالة</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col gap-2">
            {statusOrder.map((status) => {
              const count = data.statusCounts[status] ?? 0
              const pct = data.total ? Math.round((count / data.total) * 100) : 0
              return (
                <div key={status} className="flex items-center gap-3 text-sm">
                  <span className="w-32 shrink-0 text-muted-foreground">{ORDER_STATUS_LABELS_AR[status]}</span>
                  <div className="h-2 flex-1 overflow-hidden rounded-full bg-secondary">
                    <div className="h-full rounded-full bg-primary" style={{ width: `${pct}%` }} />
                  </div>
                  <span className="w-8 shrink-0 text-right tabular-nums">{count}</span>
                </div>
              )
            })}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

function FinancialRow({ label, value, emphasize }: { label: string; value: string; emphasize?: boolean }) {
  return (
    <div className="flex flex-col gap-1">
      <span className="text-xs text-muted-foreground">{label}</span>
      <span className={emphasize ? "text-base font-semibold text-primary" : "text-sm font-medium text-foreground"}>
        {value}
      </span>
    </div>
  )
}
