"use client"

import { useActionState } from "react"
import { useFormStatus } from "react-dom"
import { loginAction, type LoginResult } from "@/lib/actions/auth-actions"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

function SubmitButton() {
  const { pending } = useFormStatus()
  return (
    <Button type="submit" className="w-full" disabled={pending}>
      {pending ? "جاري تسجيل الدخول..." : "تسجيل الدخول"}
    </Button>
  )
}

export function LoginForm() {
  const [state, formAction] = useActionState<LoginResult, FormData>(
    async (_prev, formData) => loginAction(formData),
    {},
  )

  return (
    <form action={formAction} className="flex flex-col gap-4">
      <div className="flex flex-col gap-2">
        <Label htmlFor="username">اسم المستخدم</Label>
        <Input id="username" name="username" autoComplete="username" required placeholder="admin" />
      </div>
      <div className="flex flex-col gap-2">
        <Label htmlFor="password">كلمة المرور</Label>
        <Input id="password" name="password" type="password" autoComplete="current-password" required placeholder="••••••••" />
      </div>
      {state?.error && (
        <p role="alert" className="text-sm text-destructive">
          {state.error}
        </p>
      )}
      <SubmitButton />
    </form>
  )
}
