"use client"

import { useRouter, useSearchParams } from "next/navigation"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

const RANGES = [
  { value: "all", label: "كل الفترات" },
  { value: "today", label: "اليوم" },
  { value: "yesterday", label: "أمس" },
  { value: "last7", label: "آخر 7 أيام" },
  { value: "thisMonth", label: "هذا الشهر" },
]

export function DashboardRangeFilter({ current }: { current: string }) {
  const router = useRouter()
  const searchParams = useSearchParams()

  function onChange(value: string | null) {
    if (!value) return
    const params = new URLSearchParams(searchParams.toString())
    params.set("range", value)
    router.push(`/dashboard?${params.toString()}`)
  }

  return (
    <Select defaultValue={current} onValueChange={onChange}>
      <SelectTrigger className="w-40" aria-label="اختر الفترة">
        <SelectValue />
      </SelectTrigger>
      <SelectContent>
        {RANGES.map((r) => (
          <SelectItem key={r.value} value={r.value}>
            {r.label}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  )
}
