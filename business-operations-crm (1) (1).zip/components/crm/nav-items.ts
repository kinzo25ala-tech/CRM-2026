import type { Permission } from "@/lib/auth/permissions"

export interface NavItem {
  href: string
  label: string
  permission: Permission
  icon: "dashboard" | "orders" | "confirmation" | "customers" | "products" | "inventory" | "shipping" | "reports" | "settings"
}

export const NAV_ITEMS: NavItem[] = [
  { href: "/dashboard", label: "لوحة التحكم", permission: "dashboard.view", icon: "dashboard" },
  { href: "/orders", label: "الطلبات", permission: "orders.view", icon: "orders" },
  { href: "/confirmation", label: "مركز التأكيد", permission: "confirmation.view", icon: "confirmation" },
  { href: "/customers", label: "العملاء", permission: "customers.view", icon: "customers" },
  { href: "/products", label: "المنتجات", permission: "products.view", icon: "products" },
  { href: "/inventory", label: "المخزون", permission: "inventory.view", icon: "inventory" },
  { href: "/shipping", label: "الشحن", permission: "shipping.view", icon: "shipping" },
  { href: "/reports", label: "التقارير", permission: "reports.view", icon: "reports" },
  { href: "/settings", label: "الإعدادات", permission: "settings.view", icon: "settings" },
]
