"use client"

import { useState, useTransition } from "react"
import { toast } from "sonner"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { updateGeneralSettingsAction } from "@/lib/actions/settings-actions"
import type { CrmSettings } from "@/lib/services/settings-service"

export function GeneralSettingsForm({ settings }: { settings: CrmSettings }) {
  const [businessName, setBusinessName] = useState(settings.businessName)
  const [advertisingCost, setAdvertisingCost] = useState(settings.advertisingCost?.toString() ?? "")
  const [tiktokTestMode, setTiktokTestMode] = useState(settings.tiktokTestMode)
  const [notificationsEnabled, setNotificationsEnabled] = useState(settings.notificationsEnabled)
  const [isPending, startTransition] = useTransition()

  function handleSave() {
    startTransition(async () => {
      const parsedCost = advertisingCost.trim() === "" ? null : Number(advertisingCost)
      const result = await updateGeneralSettingsAction({
        businessName,
        advertisingCost: parsedCost !== null && Number.isFinite(parsedCost) ? parsedCost : null,
        tiktokTestMode,
        notificationsEnabled,
      })
      if (result?.error) toast.error(result.error)
      else toast.success("تم حفظ الإعدادات بنجاح")
    })
  }

  return (
    <div className="flex flex-col gap-5">
      <div className="flex flex-col gap-2">
        <Label htmlFor="businessName">اسم المتجر</Label>
        <Input id="businessName" value={businessName} onChange={(e) => setBusinessName(e.target.value)} />
      </div>

      <div className="flex flex-col gap-2">
        <Label htmlFor="advertisingCost">تكلفة الإعلانات الشهرية (اختياري، بالدينار)</Label>
        <Input
          id="advertisingCost"
          type="number"
          placeholder="غير متوفر"
          value={advertisingCost}
          onChange={(e) => setAdvertisingCost(e.target.value)}
        />
        <p className="text-xs text-muted-foreground">
          يُستخدم لحساب النتيجة الصافية التقديرية في لوحة التحكم. اتركه فارغاً إذا لم تكن متوفرة.
        </p>
      </div>

      <div className="flex items-center justify-between rounded-md border border-border p-3">
        <div>
          <p className="text-sm font-medium text-foreground">وضع تيك توك التجريبي</p>
          <p className="text-xs text-muted-foreground">عند التفعيل، تُعتبر الأحداث تجريبية ولن يتم اعتبارها مبيعات حقيقية.</p>
        </div>
        <Switch checked={tiktokTestMode} onCheckedChange={setTiktokTestMode} />
      </div>

      <div className="flex items-center justify-between rounded-md border border-border p-3">
        <div>
          <p className="text-sm font-medium text-foreground">التنبيهات</p>
          <p className="text-xs text-muted-foreground">تفعيل التنبيهات الداخلية للطلبات الجديدة والمؤجلة.</p>
        </div>
        <Switch checked={notificationsEnabled} onCheckedChange={setNotificationsEnabled} />
      </div>

      <div>
        <Button onClick={handleSave} disabled={isPending}>
          {isPending ? "جاري الحفظ..." : "حفظ الإعدادات"}
        </Button>
      </div>
    </div>
  )
}
