import type { ReactNode } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { cn } from "@/lib/utils"

export function StatCard({
  label,
  value,
  icon,
  tone = "default",
  className,
}: {
  label: string
  value: string
  icon?: ReactNode
  tone?: "default" | "primary" | "warning" | "danger" | "success"
  className?: string
}) {
  const toneClasses: Record<string, string> = {
    default: "text-foreground",
    primary: "text-primary",
    warning: "text-amber-400",
    danger: "text-destructive",
    success: "text-emerald-400",
  }

  return (
    <Card className={cn("border-border", className)}>
      <CardContent className="flex items-center justify-between gap-3 p-4">
        <div className="flex flex-col gap-1">
          <span className="text-xs text-muted-foreground">{label}</span>
          <span className={cn("text-2xl font-semibold tabular-nums text-balance", toneClasses[tone])}>{value}</span>
        </div>
        {icon && (
          <div className="flex size-9 shrink-0 items-center justify-center rounded-md bg-secondary text-muted-foreground">
            {icon}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
