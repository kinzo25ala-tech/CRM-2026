import Link from "next/link"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { OrderStatusBadge } from "@/components/crm/status-badge"
import { DELIVERY_TYPE_LABELS_AR, type Order } from "@/lib/domain/types"
import { formatPhoneForDisplay } from "@/lib/domain/phone"

export function OrdersTable({ orders }: { orders: Order[] }) {
  if (orders.length === 0) {
    return <p className="rounded-md border border-dashed border-border p-8 text-center text-sm text-muted-foreground">لا توجد طلبات مطابقة</p>
  }

  return (
    <div className="overflow-x-auto rounded-md border border-border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="text-right">رقم الطلب</TableHead>
            <TableHead className="text-right">التاريخ</TableHead>
            <TableHead className="text-right">العميل</TableHead>
            <TableHead className="text-right">الهاتف</TableHead>
            <TableHead className="text-right">الولاية</TableHead>
            <TableHead className="text-right">المنتج</TableHead>
            <TableHead className="text-right">الكمية</TableHead>
            <TableHead className="text-right">الإجمالي</TableHead>
            <TableHead className="text-right">التأكيد</TableHead>
            <TableHead className="text-right">التوصيل</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {orders.map((order) => (
            <TableRow key={order.orderNumber} className="hover:bg-secondary/40">
              <TableCell className="font-medium">
                <Link href={`/orders/${encodeURIComponent(order.orderNumber)}`} className="text-primary hover:underline">
                  {order.orderNumber}
                </Link>
              </TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">
                {new Date(order.orderDate).toLocaleDateString("ar-DZ")}
              </TableCell>
              <TableCell>{order.customerName || "—"}</TableCell>
              <TableCell className="whitespace-nowrap" dir="ltr">
                {formatPhoneForDisplay(order.phoneNormalized) || order.phoneRaw}
              </TableCell>
              <TableCell>{order.wilaya || "—"}</TableCell>
              <TableCell className="max-w-40 truncate">{order.productSummary}</TableCell>
              <TableCell>{order.quantity}</TableCell>
              <TableCell className="whitespace-nowrap tabular-nums">{order.total.toLocaleString("ar-DZ")} د.ج</TableCell>
              <TableCell>
                <OrderStatusBadge status={order.status} />
              </TableCell>
              <TableCell>{DELIVERY_TYPE_LABELS_AR[order.deliveryType]}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}
