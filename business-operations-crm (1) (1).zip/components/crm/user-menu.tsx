"use client"

import { LogOut, User } from "lucide-react"
import { logoutAction } from "@/lib/actions/auth-actions"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"

export function UserMenu({ name, roleLabel }: { name: string; roleLabel: string }) {
  const initials = name.trim().slice(0, 1) || "?"

  return (
    <DropdownMenu>
      <DropdownMenuTrigger
        render={<Button variant="ghost" className="flex h-auto items-center gap-2 px-2 py-1.5" />}
      >
        <Avatar className="size-7">
          <AvatarFallback className="bg-primary/15 text-primary text-xs">{initials}</AvatarFallback>
        </Avatar>
        <span className="hidden text-right text-sm leading-tight sm:flex sm:flex-col">
          <span className="font-medium">{name}</span>
          <span className="text-xs text-muted-foreground">{roleLabel}</span>
        </span>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-48">
        <DropdownMenuLabel className="flex items-center gap-2">
          <User className="size-4" aria-hidden="true" />
          {name}
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        <form action={logoutAction}>
          <DropdownMenuItem
            render={<button type="submit" className="flex w-full items-center gap-2 text-destructive" />}
          >
            <LogOut className="size-4" aria-hidden="true" />
            تسجيل الخروج
          </DropdownMenuItem>
        </form>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
