"use client"

import { useRouter, useSearchParams } from "next/navigation"
import { useState, useTransition } from "react"
import { Search } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ORDER_STATUS_LABELS_AR, type OrderStatus } from "@/lib/domain/types"

export function OrdersFilters({
  wilayas,
  products,
  defaults,
}: {
  wilayas: string[]
  products: string[]
  defaults: { search?: string; status?: string; wilaya?: string; product?: string }
}) {
  const router = useRouter()
  const searchParams = useSearchParams()
  const [search, setSearch] = useState(defaults.search ?? "")
  const [, startTransition] = useTransition()

  function updateParam(key: string, value?: string | null) {
    const params = new URLSearchParams(searchParams.toString())
    if (value) params.set(key, value)
    else params.delete(key)
    params.delete("page")
    startTransition(() => router.push(`/orders?${params.toString()}`))
  }

  return (
    <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
      <div className="relative flex-1">
        <Search className="absolute right-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
        <Input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.nativeEvent.isComposing) updateParam("search", search)
          }}
          onBlur={() => updateParam("search", search)}
          placeholder="بحث برقم الطلب، العميل أو الهاتف"
          className="pr-9"
          aria-label="بحث عن طلب"
        />
      </div>

      <Select defaultValue={defaults.status ?? "all"} onValueChange={(v) => updateParam("status", v === "all" ? undefined : v)}>
        <SelectTrigger className="w-full sm:w-44" aria-label="فلترة حسب الحالة">
          <SelectValue placeholder="الحالة" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="all">كل الحالات</SelectItem>
          {(Object.keys(ORDER_STATUS_LABELS_AR) as OrderStatus[]).map((s) => (
            <SelectItem key={s} value={s}>
              {ORDER_STATUS_LABELS_AR[s]}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      <Select defaultValue={defaults.wilaya ?? "all"} onValueChange={(v) => updateParam("wilaya", v === "all" ? undefined : v)}>
        <SelectTrigger className="w-full sm:w-40" aria-label="فلترة حسب الولاية">
          <SelectValue placeholder="الولاية" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="all">كل الولايات</SelectItem>
          {wilayas.map((w) => (
            <SelectItem key={w} value={w}>
              {w}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      <Select defaultValue={defaults.product ?? "all"} onValueChange={(v) => updateParam("product", v === "all" ? undefined : v)}>
        <SelectTrigger className="w-full sm:w-44" aria-label="فلترة حسب المنتج">
          <SelectValue placeholder="المنتج" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="all">كل المنتجات</SelectItem>
          {products.map((p) => (
            <SelectItem key={p} value={p}>
              {p}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  )
}
