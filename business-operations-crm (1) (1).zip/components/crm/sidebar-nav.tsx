"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import {
  LayoutDashboard,
  ShoppingCart,
  PhoneCall,
  Users,
  Package,
  Boxes,
  Truck,
  BarChart3,
  Settings,
} from "lucide-react"
import { cn } from "@/lib/utils"
import type { NavItem } from "@/components/crm/nav-items"

const ICONS: Record<NavItem["icon"], React.ComponentType<{ className?: string }>> = {
  dashboard: LayoutDashboard,
  orders: ShoppingCart,
  confirmation: PhoneCall,
  customers: Users,
  products: Package,
  inventory: Boxes,
  shipping: Truck,
  reports: BarChart3,
  settings: Settings,
}

export function SidebarNav({ items, onNavigate }: { items: NavItem[]; onNavigate?: () => void }) {
  const pathname = usePathname()

  return (
    <nav className="flex flex-col gap-1 p-3" aria-label="التنقل الرئيسي">
      {items.map((item) => {
        const Icon = ICONS[item.icon]
        const active = pathname === item.href || pathname.startsWith(item.href + "/")
        return (
          <Link
            key={item.href}
            href={item.href}
            onClick={onNavigate}
            className={cn(
              "flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors",
              active
                ? "bg-sidebar-accent text-sidebar-accent-foreground"
                : "text-sidebar-foreground/70 hover:bg-sidebar-accent/60 hover:text-sidebar-foreground",
            )}
            aria-current={active ? "page" : undefined}
          >
            <Icon className="size-4 shrink-0" aria-hidden="true" />
            <span>{item.label}</span>
          </Link>
        )
      })}
    </nav>
  )
}
