import type { ReactNode } from "react"
import { Radar } from "lucide-react"
import { SidebarNav } from "@/components/crm/sidebar-nav"
import { MobileNav } from "@/components/crm/mobile-nav"
import { UserMenu } from "@/components/crm/user-menu"
import { NAV_ITEMS } from "@/components/crm/nav-items"
import { roleHasPermission } from "@/lib/auth/permissions"
import { ROLE_LABELS_AR } from "@/lib/auth/permissions"
import type { SessionPayload } from "@/lib/auth/session"

export function CrmShell({
  session,
  businessName,
  children,
}: {
  session: SessionPayload
  businessName: string
  children: ReactNode
}) {
  const items = NAV_ITEMS.filter((item) => roleHasPermission(session.role, item.permission))

  return (
    <div dir="rtl" className="flex min-h-screen bg-background text-foreground">
      <aside className="hidden w-60 shrink-0 border-l border-sidebar-border bg-sidebar text-sidebar-foreground md:flex md:flex-col">
        <div className="flex items-center gap-2 border-b border-sidebar-border px-4 py-4">
          <Radar className="size-5 text-primary" aria-hidden="true" />
          <span className="truncate text-sm font-semibold">{businessName}</span>
        </div>
        <div className="flex-1 overflow-y-auto">
          <SidebarNav items={items} />
        </div>
      </aside>

      <div className="flex min-h-screen flex-1 flex-col">
        <header className="sticky top-0 z-10 flex items-center justify-between border-b border-border bg-card/80 px-4 py-3 backdrop-blur">
          <div className="flex items-center gap-2">
            <MobileNav items={items} businessName={businessName} />
            <span className="text-sm font-medium text-muted-foreground md:hidden">{businessName}</span>
          </div>
          <UserMenu name={session.name} roleLabel={ROLE_LABELS_AR[session.role]} />
        </header>

        <main className="flex-1 p-4 md:p-6">{children}</main>
      </div>
    </div>
  )
}
