import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"
import { ORDER_STATUS_LABELS_AR, type OrderStatus } from "@/lib/domain/types"

const STATUS_STYLES: Record<OrderStatus, string> = {
  NEW: "bg-secondary text-secondary-foreground border-transparent",
  PENDING_CONFIRMATION: "bg-amber-500/15 text-amber-400 border-amber-500/30",
  CALLED: "bg-sky-500/15 text-sky-400 border-sky-500/30",
  CONFIRMED: "bg-primary/15 text-primary border-primary/30",
  POSTPONED: "bg-orange-500/15 text-orange-400 border-orange-500/30",
  CANCELLED: "bg-destructive/15 text-destructive border-destructive/30",
  READY_TO_SHIP: "bg-violet-500/15 text-violet-400 border-violet-500/30",
  SHIPPED: "bg-blue-500/15 text-blue-400 border-blue-500/30",
  IN_TRANSIT: "bg-indigo-500/15 text-indigo-400 border-indigo-500/30",
  DELIVERED: "bg-emerald-500/15 text-emerald-400 border-emerald-500/30",
  RETURNED: "bg-rose-500/15 text-rose-400 border-rose-500/30",
}

export function OrderStatusBadge({ status, className }: { status: OrderStatus; className?: string }) {
  return (
    <Badge variant="outline" className={cn("border font-normal", STATUS_STYLES[status], className)}>
      {ORDER_STATUS_LABELS_AR[status]}
    </Badge>
  )
}
