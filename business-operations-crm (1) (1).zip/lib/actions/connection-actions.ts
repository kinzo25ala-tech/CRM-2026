"use server"

import { revalidatePath } from "next/cache"
import { getSession } from "@/lib/auth/session"
import { assertPermission } from "@/lib/auth/permissions"
import {
  createConnection,
  updateConnection,
  setActiveConnection,
  deactivateConnection,
  listConnections,
} from "@/lib/data/connection-store"
import { extractSpreadsheetId, hasGoogleCredentials } from "@/lib/data/google-sheets-client"
import {
  testConnectionById,
  listTabsForConnection,
  readHeadersAndAutoMap,
  previewSync,
  runFullSync,
} from "@/lib/services/sync-service"
import { validateMapping } from "@/lib/data/sheet-mapping"
import { recordAudit } from "@/lib/services/audit-service"

async function requireOwnerOrManager() {
  const session = await getSession()
  if (!session) throw new Error("يجب تسجيل الدخول")
  assertPermission(session.role, "settings.datasources.manage")
  return session
}

export async function getConnectionsAction() {
  await requireOwnerOrManager()
  return { connections: await listConnections(), hasCredentials: hasGoogleCredentials() }
}

export async function addConnectionAction(input: { name: string; spreadsheetUrlOrId: string }) {
  const session = await requireOwnerOrManager()
  if (!hasGoogleCredentials()) {
    return { error: "لم يتم تكوين بيانات اعتماد Google بعد. يرجى إضافة حساب الخدمة أولاً." }
  }
  const spreadsheetId = extractSpreadsheetId(input.spreadsheetUrlOrId)
  const conn = await createConnection({ name: input.name, spreadsheetId })
  await recordAudit(session.username, "CONNECTION_CREATED", "connection", conn.connectionId, input.name)
  revalidatePath("/settings/data-sources")
  return { connection: conn }
}

export async function testConnectionAction(connectionId: string) {
  await requireOwnerOrManager()
  return testConnectionById(connectionId)
}

export async function listTabsAction(connectionId: string) {
  await requireOwnerOrManager()
  return listTabsForConnection(connectionId)
}

export async function autoMapAction(connectionId: string, tab: string, headerRow: number) {
  await requireOwnerOrManager()
  return readHeadersAndAutoMap(connectionId, tab, headerRow)
}

export async function saveMappingAction(input: {
  connectionId: string
  tab: string
  headerRow: number
  mapping: Record<string, string>
}) {
  const session = await requireOwnerOrManager()
  const { valid, missing } = validateMapping(input.mapping)
  if (!valid) {
    return { error: `الربط غير مكتمل. الحقول الناقصة: ${missing.join(", ")}` }
  }
  const conn = await updateConnection(input.connectionId, {
    selectedOrdersTab: input.tab,
    headerRow: input.headerRow,
    mapping: input.mapping,
  })
  await recordAudit(session.username, "MAPPING_SAVED", "connection", input.connectionId)
  revalidatePath("/settings/data-sources")
  return { connection: conn }
}

export async function previewSyncAction(connectionId: string) {
  await requireOwnerOrManager()
  try {
    return { result: await previewSync(connectionId) }
  } catch (err) {
    return { error: err instanceof Error ? err.message : "حدث خطأ غير متوقع" }
  }
}

export async function runFullSyncAction(connectionId: string) {
  const session = await requireOwnerOrManager()
  try {
    const result = await runFullSync(connectionId, session.username)
    revalidatePath("/orders")
    revalidatePath("/dashboard")
    return { result }
  } catch (err) {
    return { error: err instanceof Error ? err.message : "حدث خطأ غير متوقع" }
  }
}

export async function activateConnectionAction(connectionId: string) {
  const session = await requireOwnerOrManager()
  const conns = await listConnections()
  const conn = conns.find((c) => c.connectionId === connectionId)
  if (!conn?.selectedOrdersTab || !validateMapping(conn.mapping).valid) {
    return { error: "يجب إكمال الربط قبل التفعيل" }
  }
  await setActiveConnection(connectionId)
  await recordAudit(session.username, "CONNECTION_ACTIVATED", "connection", connectionId)
  revalidatePath("/settings/data-sources")
  return { ok: true }
}

export async function deactivateConnectionAction(connectionId: string) {
  const session = await requireOwnerOrManager()
  await deactivateConnection(connectionId)
  await recordAudit(session.username, "CONNECTION_DEACTIVATED", "connection", connectionId)
  revalidatePath("/settings/data-sources")
  return { ok: true }
}
