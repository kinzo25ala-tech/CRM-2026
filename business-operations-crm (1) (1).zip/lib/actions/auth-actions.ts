"use server"

import { redirect } from "next/navigation"
import { findUserByUsername } from "@/lib/auth/users-store"
import { verifyPassword } from "@/lib/auth/password"
import { createSession, destroySession } from "@/lib/auth/session"
import { recordAudit } from "@/lib/services/audit-service"

export interface LoginResult {
  error?: string
}

export async function loginAction(formData: FormData): Promise<LoginResult> {
  const username = String(formData.get("username") ?? "").trim()
  const password = String(formData.get("password") ?? "")

  if (!username || !password) {
    return { error: "يرجى إدخال اسم المستخدم وكلمة المرور" }
  }

  const user = await findUserByUsername(username)
  if (!user || !user.active) {
    return { error: "اسم المستخدم أو كلمة المرور غير صحيحة" }
  }

  const ok = verifyPassword(password, user.passwordHash, user.passwordSalt)
  if (!ok) {
    return { error: "اسم المستخدم أو كلمة المرور غير صحيحة" }
  }

  await createSession({ userId: user.id, username: user.username, name: user.name, role: user.role })
  await recordAudit(user.username, "LOGIN", "user", user.id)

  redirect("/dashboard")
}

export async function logoutAction() {
  await destroySession()
  redirect("/login")
}
