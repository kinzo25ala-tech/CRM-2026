"use server"

import { revalidatePath } from "next/cache"
import { getSession } from "@/lib/auth/session"
import { assertPermission } from "@/lib/auth/permissions"
import { changeOrderStatus, updateOrderFields } from "@/lib/services/order-service"
import { recordCallAttempt } from "@/lib/services/call-attempts-service"
import { enqueueTikTokEvent } from "@/lib/services/tiktok-service"
import { ACTIVE_CONFIRMATION_STATUSES } from "@/lib/domain/order-state"
import type { CallResult, OrderStatus } from "@/lib/domain/types"

async function requireSession() {
  const session = await getSession()
  if (!session) throw new Error("يجب تسجيل الدخول")
  return session
}

export async function updateOrderAction(orderNumber: string, patch: Record<string, unknown>) {
  const session = await requireSession()
  assertPermission(session.role, "orders.edit")
  try {
    await updateOrderFields(orderNumber, patch as any, session.username)
    revalidatePath(`/orders/${orderNumber}`)
    revalidatePath("/orders")
    return { ok: true }
  } catch (err) {
    return { error: err instanceof Error ? err.message : "حدث خطأ غير متوقع" }
  }
}

const RESULT_TO_STATUS: Record<CallResult, OrderStatus> = {
  CONFIRMED: "CONFIRMED",
  NO_ANSWER: "CALLED",
  PHONE_OFF: "CALLED",
  WRONG_NUMBER: "CALLED",
  POSTPONED: "POSTPONED",
  CANCELLED: "CANCELLED",
}

/**
 * Single action that powers every Confirmation Center button:
 * validates permission + current state, writes the call attempt, updates order
 * status (and source cells via the repository), fires TikTok CONFIRM event on
 * confirmation, and returns the next order for the agent to work.
 */
export async function recordConfirmationActionAction(input: {
  orderNumber: string
  result: CallResult
  note?: string
  callbackAt?: string
}) {
  const session = await requireSession()
  assertPermission(session.role, "confirmation.act")

  try {
    await recordCallAttempt({
      orderNumber: input.orderNumber,
      agent: session.username,
      result: input.result,
      note: input.note,
      callbackAt: input.callbackAt,
    })

    const toStatus = RESULT_TO_STATUS[input.result]
    await changeOrderStatus(input.orderNumber, toStatus, session.username, input.note)

    if (input.result === "POSTPONED" && input.callbackAt) {
      await updateOrderFields(input.orderNumber, { postponedUntil: input.callbackAt }, session.username)
    }

    if (input.result === "CONFIRMED") {
      await enqueueTikTokEvent(input.orderNumber, "CONFIRM", session.username)
    }

    revalidatePath("/confirmation")
    revalidatePath("/orders")
    revalidatePath(`/orders/${input.orderNumber}`)
    return { ok: true }
  } catch (err) {
    return { error: err instanceof Error ? err.message : "حدث خطأ غير متوقع" }
  }
}

export async function markDeliveredAction(orderNumber: string) {
  const session = await requireSession()
  assertPermission(session.role, "shipping.edit")
  try {
    await changeOrderStatus(orderNumber, "DELIVERED", session.username)
    await enqueueTikTokEvent(orderNumber, "PURCHASE", session.username)
    revalidatePath("/shipping")
    revalidatePath(`/orders/${orderNumber}`)
    return { ok: true }
  } catch (err) {
    return { error: err instanceof Error ? err.message : "حدث خطأ غير متوقع" }
  }
}

export const CONFIRMATION_ACTIVE_STATUSES = ACTIVE_CONFIRMATION_STATUSES
