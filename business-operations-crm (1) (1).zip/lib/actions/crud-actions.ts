"use server"

import { revalidatePath } from "next/cache"
import { getSession } from "@/lib/auth/session"
import { assertPermission } from "@/lib/auth/permissions"
import { setCustomerNotes, setCustomerBlacklist } from "@/lib/services/customer-service"
import { createProduct, updateProduct, deleteProduct } from "@/lib/services/product-service"
import { updateInventory } from "@/lib/services/inventory-service"
import { createShipment, updateShipmentStatus } from "@/lib/services/shipping-service"
import { updateSettings } from "@/lib/services/settings-service"
import { createUser, setUserActive, updateUserRole } from "@/lib/auth/users-store"
import { normalizePhone } from "@/lib/domain/phone"
import type { Product, Role, ShipmentStatus } from "@/lib/domain/types"

async function requireSession() {
  const session = await getSession()
  if (!session) throw new Error("يجب تسجيل الدخول")
  return session
}

function errOf(err: unknown) {
  return err instanceof Error ? err.message : "حدث خطأ غير متوقع"
}

// --- Customers ---
export async function updateCustomerNotesAction(phone: string, notes: string) {
  const session = await requireSession()
  assertPermission(session.role, "customers.edit")
  await setCustomerNotes(normalizePhone(phone), notes)
  revalidatePath(`/customers/${phone}`)
  return { ok: true }
}

export async function toggleCustomerBlacklistAction(phone: string, blacklisted: boolean) {
  const session = await requireSession()
  assertPermission(session.role, "customers.edit")
  await setCustomerBlacklist(normalizePhone(phone), blacklisted)
  revalidatePath(`/customers/${phone}`)
  revalidatePath("/customers")
  return { ok: true }
}

// --- Products ---
export async function createProductAction(input: Omit<Product, "id" | "createdAt" | "updatedAt">) {
  const session = await requireSession()
  assertPermission(session.role, "products.edit")
  try {
    await createProduct(input)
    revalidatePath("/products")
    return { ok: true }
  } catch (err) {
    return { error: errOf(err) }
  }
}

export async function updateProductAction(id: string, patch: Partial<Product>) {
  const session = await requireSession()
  assertPermission(session.role, "products.edit")
  await updateProduct(id, patch)
  revalidatePath("/products")
  return { ok: true }
}

export async function deleteProductAction(id: string) {
  const session = await requireSession()
  assertPermission(session.role, "products.edit")
  await deleteProduct(id)
  revalidatePath("/products")
  return { ok: true }
}

// --- Inventory ---
export async function updateInventoryAction(productId: string, patch: { currentStock?: number; reserved?: number; damaged?: number }) {
  const session = await requireSession()
  assertPermission(session.role, "inventory.edit")
  await updateInventory(productId, patch)
  revalidatePath("/inventory")
  return { ok: true }
}

// --- Shipping ---
export async function createShipmentAction(input: {
  orderNumber: string
  carrier: string
  trackingNumber?: string
  deliveryMode: "HOME" | "STOP_DESK" | "UNKNOWN"
  stopDeskName?: string
  shippingFee: number
}) {
  const session = await requireSession()
  assertPermission(session.role, "shipping.edit")
  try {
    await createShipment({ ...input, actor: session.username })
    revalidatePath("/shipping")
    revalidatePath(`/orders/${input.orderNumber}`)
    return { ok: true }
  } catch (err) {
    return { error: errOf(err) }
  }
}

export async function updateShipmentStatusAction(id: string, status: ShipmentStatus) {
  const session = await requireSession()
  assertPermission(session.role, "shipping.edit")
  try {
    await updateShipmentStatus(id, status, session.username)
    revalidatePath("/shipping")
    return { ok: true }
  } catch (err) {
    return { error: errOf(err) }
  }
}

// --- Settings ---
export async function updateSettingsAction(patch: {
  businessName?: string
  advertisingCost?: number | null
  tiktokTestMode?: boolean
  notificationsEnabled?: boolean
}) {
  const session = await requireSession()
  assertPermission(session.role, "settings.view")
  await updateSettings(patch)
  revalidatePath("/settings")
  return { ok: true }
}

// --- Users ---
export async function createUserAction(input: { username: string; name: string; role: Role; password: string }) {
  const session = await requireSession()
  assertPermission(session.role, "settings.users.manage")
  try {
    await createUser(input)
    revalidatePath("/settings/users")
    return { ok: true }
  } catch (err) {
    return { error: errOf(err) }
  }
}

export async function setUserActiveAction(id: string, active: boolean) {
  const session = await requireSession()
  assertPermission(session.role, "settings.users.manage")
  await setUserActive(id, active)
  revalidatePath("/settings/users")
  return { ok: true }
}

export async function updateUserRoleAction(id: string, role: Role) {
  const session = await requireSession()
  assertPermission(session.role, "settings.users.manage")
  await updateUserRole(id, role)
  revalidatePath("/settings/users")
  return { ok: true }
}
