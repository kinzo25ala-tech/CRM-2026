"use server"

import { revalidatePath } from "next/cache"
import { getSession } from "@/lib/auth/session"
import { assertPermission } from "@/lib/auth/permissions"
import { updateSettings } from "@/lib/services/settings-service"
import { recordAudit } from "@/lib/services/audit-service"

async function requireSession() {
  const session = await getSession()
  if (!session) throw new Error("يجب تسجيل الدخول")
  return session
}

export async function updateGeneralSettingsAction(patch: {
  businessName?: string
  advertisingCost?: number | null
  tiktokTestMode?: boolean
  notificationsEnabled?: boolean
}) {
  try {
    const session = await requireSession()
    assertPermission(session.role, "settings.view")
    await updateSettings(patch)
    await recordAudit(session.username, "SETTINGS_UPDATED", "settings", "-", JSON.stringify(patch))
    revalidatePath("/settings")
    revalidatePath("/dashboard")
    return { ok: true }
  } catch (err) {
    return { error: err instanceof Error ? err.message : "حدث خطأ غير متوقع" }
  }
}
