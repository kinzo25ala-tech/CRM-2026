import "server-only"
import { randomUUID } from "crypto"
import { mutateStore, readStore } from "@/lib/data/json-store"
import { getOrder } from "@/lib/services/order-service"
import { recordAudit } from "@/lib/services/audit-service"
import type { Order, TikTokEventType, TikTokOutboxEvent } from "@/lib/domain/types"

const STORE_NAME = "CRM_AdEvents"

function idempotencyKey(type: TikTokEventType, orderNumber: string) {
  return type === "CONFIRM" ? `CONFIRM-${orderNumber}` : `PURCHASE-${orderNumber}`
}

function hasAccessToken() {
  return Boolean(process.env.TIKTOK_ACCESS_TOKEN && process.env.TIKTOK_PIXEL_CODE)
}

function buildPayload(order: Order, type: TikTokEventType) {
  return {
    event: type === "CONFIRM" ? "CompletePayment" : "PlaceAnOrder",
    event_time: Math.floor(Date.now() / 1000),
    context: {
      ad: { ttclid: order.attribution.ttclid },
      user: { ttp: order.attribution.ttp, phone: order.phoneNormalized },
    },
    properties: {
      currency: "DZD",
      value: order.total,
      order_id: order.orderNumber,
    },
  }
}

/** Enqueue a TikTok event with deterministic idempotency. Never duplicates. */
export async function enqueueTikTokEvent(orderNumber: string, type: TikTokEventType, actor: string) {
  if (orderNumber.toUpperCase().includes("TEST")) return null // never send events for test orders

  const order = await getOrder(orderNumber)
  if (!order || order.isTest) return null

  const key = idempotencyKey(type, orderNumber)

  return mutateStore<TikTokOutboxEvent[]>(STORE_NAME, [], (list) => {
    if (list.some((e) => e.idempotencyKey === key)) return list // already enqueued/sent, skip
    const event: TikTokOutboxEvent = {
      id: randomUUID(),
      orderNumber,
      eventType: type,
      idempotencyKey: key,
      status: hasAccessToken() ? "PENDING" : "STUBBED",
      payload: buildPayload(order, type),
      attempts: 0,
      createdAt: new Date().toISOString(),
    }
    return [...list, event]
  }).then((all) => all.find((e) => e.idempotencyKey === key)!)
}

/** Attempts to actually send PENDING events. In stub mode (no access token) events stay STUBBED and are never claimed as sent. */
export async function processOutbox(actor: string): Promise<{ sent: number; stubbed: number; failed: number }> {
  const list = await readStore<TikTokOutboxEvent[]>(STORE_NAME, [])
  const pending = list.filter((e) => e.status === "PENDING" || e.status === "STUBBED")

  let sent = 0
  let stubbed = 0
  let failed = 0

  for (const event of pending) {
    if (!hasAccessToken()) {
      stubbed++
      continue
    }
    try {
      const res = await fetch("https://business-api.tiktok.com/open_api/v1.3/event/track/", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Access-Token": process.env.TIKTOK_ACCESS_TOKEN!,
        },
        body: JSON.stringify({
          pixel_code: process.env.TIKTOK_PIXEL_CODE,
          event: (event.payload as any).event,
          event_id: event.idempotencyKey,
          timestamp: new Date().toISOString(),
          context: (event.payload as any).context,
          properties: (event.payload as any).properties,
        }),
      })
      if (!res.ok) throw new Error(`TikTok API error ${res.status}`)
      await mutateStore<TikTokOutboxEvent[]>(STORE_NAME, [], (all) =>
        all.map((e) => (e.id === event.id ? { ...e, status: "SENT", sentAt: new Date().toISOString() } : e)),
      )
      sent++
    } catch (err) {
      failed++
      await mutateStore<TikTokOutboxEvent[]>(STORE_NAME, [], (all) =>
        all.map((e) =>
          e.id === event.id
            ? { ...e, attempts: e.attempts + 1, lastError: err instanceof Error ? err.message : "خطأ غير معروف" }
            : e,
        ),
      )
    }
  }

  if (sent + failed > 0) await recordAudit(actor, "TIKTOK_OUTBOX_PROCESSED", "tiktok", "-", `sent=${sent} failed=${failed}`)

  return { sent, stubbed, failed }
}

export async function listTikTokEvents(): Promise<TikTokOutboxEvent[]> {
  return readStore<TikTokOutboxEvent[]>(STORE_NAME, [])
}

export function isTikTokConfigured() {
  return hasAccessToken()
}
