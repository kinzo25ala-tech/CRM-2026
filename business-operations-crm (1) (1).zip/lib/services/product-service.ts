import "server-only"
import { randomUUID } from "crypto"
import { mutateStore, readStore } from "@/lib/data/json-store"
import { getAllOrders } from "@/lib/services/order-service"
import type { Product } from "@/lib/domain/types"

const STORE_NAME = "CRM_Products"

async function seedFromOrdersIfEmpty(): Promise<Product[]> {
  return mutateStore<Product[]>(STORE_NAME, [], async (products) => {
    if (products.length > 0) return products
    const orders = await getAllOrders()
    const names = [...new Set(orders.flatMap((o) => o.lines.map((l) => l.productName)))].filter(Boolean)
    const now = new Date().toISOString()
    return names.map((name) => {
      const line = orders.flatMap((o) => o.lines).find((l) => l.productName === name)
      return {
        id: randomUUID(),
        name,
        aliases: [],
        price: line?.unitPrice ?? 0,
        status: "ACTIVE" as const,
        createdAt: now,
        updatedAt: now,
      }
    })
  })
}

export async function listProducts(): Promise<Product[]> {
  return seedFromOrdersIfEmpty()
}

export async function createProduct(input: Omit<Product, "id" | "createdAt" | "updatedAt">): Promise<Product> {
  const now = new Date().toISOString()
  return mutateStore<Product[]>(STORE_NAME, [], (products) => [
    ...products,
    { ...input, id: randomUUID(), createdAt: now, updatedAt: now },
  ]).then((all) => all[all.length - 1])
}

export async function updateProduct(id: string, patch: Partial<Product>): Promise<Product> {
  const updated = await mutateStore<Product[]>(STORE_NAME, [], (products) =>
    products.map((p) => (p.id === id ? { ...p, ...patch, updatedAt: new Date().toISOString() } : p)),
  )
  return updated.find((p) => p.id === id)!
}

export async function deleteProduct(id: string): Promise<void> {
  await mutateStore<Product[]>(STORE_NAME, [], (products) => products.filter((p) => p.id !== id))
}
