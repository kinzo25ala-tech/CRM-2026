import "server-only"
import { mutateStore, readStore } from "@/lib/data/json-store"
import { listProducts } from "@/lib/services/product-service"
import { getAllOrders } from "@/lib/services/order-service"
import type { InventoryRecord } from "@/lib/domain/types"

const STORE_NAME = "CRM_Inventory"

async function ensureRecordsExist(): Promise<InventoryRecord[]> {
  return mutateStore<InventoryRecord[]>(STORE_NAME, [], async (records) => {
    const products = await listProducts()
    const missing = products.filter((p) => !records.some((r) => r.productId === p.id))
    if (missing.length === 0) return records
    const now = new Date().toISOString()
    const added = missing.map((p) => ({
      productId: p.id,
      currentStock: 0,
      reserved: 0,
      sold: 0,
      returned: 0,
      damaged: 0,
      updatedAt: now,
    }))
    return [...records, ...added]
  })
}

export async function listInventory() {
  const records = await ensureRecordsExist()
  const products = await listProducts()
  const orders = await getAllOrders()

  return records.map((r) => {
    const product = products.find((p) => p.id === r.productId)
    const sold = orders.filter(
      (o) => o.status === "DELIVERED" && o.lines.some((l) => l.productName === product?.name),
    ).length
    const returned = orders.filter(
      (o) => o.status === "RETURNED" && o.lines.some((l) => l.productName === product?.name),
    ).length
    const available = r.currentStock - r.reserved
    return { ...r, sold, returned, available, product }
  })
}

export async function updateInventory(productId: string, patch: Partial<InventoryRecord>) {
  await ensureRecordsExist()
  const updated = await mutateStore<InventoryRecord[]>(STORE_NAME, [], (records) =>
    records.map((r) => (r.productId === productId ? { ...r, ...patch, updatedAt: new Date().toISOString() } : r)),
  )
  return updated.find((r) => r.productId === productId)
}
