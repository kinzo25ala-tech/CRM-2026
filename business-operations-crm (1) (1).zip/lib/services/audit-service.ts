import "server-only"
import { randomUUID } from "crypto"
import { mutateStore, readStore } from "@/lib/data/json-store"
import type { AuditLogEntry } from "@/lib/domain/types"

const STORE_NAME = "CRM_AuditLog"

export async function recordAudit(actor: string, action: string, entity: string, entityId: string, details?: string) {
  const entry: AuditLogEntry = {
    id: randomUUID(),
    actor,
    action,
    entity,
    entityId,
    details,
    timestamp: new Date().toISOString(),
  }
  await mutateStore<AuditLogEntry[]>(STORE_NAME, [], (list) => [entry, ...list].slice(0, 2000))
  return entry
}

export async function listAudit(limit = 200): Promise<AuditLogEntry[]> {
  const list = await readStore<AuditLogEntry[]>(STORE_NAME, [])
  return list.slice(0, limit)
}
