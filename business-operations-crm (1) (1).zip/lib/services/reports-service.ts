import "server-only"
import { getAllOrders } from "@/lib/services/order-service"
import { listProducts } from "@/lib/services/product-service"
import { computeFinancialSummary, computeKpis } from "@/lib/domain/pricing"
import { getSettings } from "@/lib/services/settings-service"
import type { Order } from "@/lib/domain/types"

export type DateRangeKey = "today" | "yesterday" | "last7" | "thisMonth" | "custom" | "all"

export function filterByRange(orders: Order[], range: DateRangeKey, from?: string, to?: string): Order[] {
  if (range === "all") return orders
  const now = new Date()
  const startOfDay = (d: Date) => new Date(d.getFullYear(), d.getMonth(), d.getDate())

  if (range === "today") {
    const start = startOfDay(now)
    return orders.filter((o) => new Date(o.orderDate) >= start)
  }
  if (range === "yesterday") {
    const start = startOfDay(new Date(now.getTime() - 86400000))
    const end = startOfDay(now)
    return orders.filter((o) => new Date(o.orderDate) >= start && new Date(o.orderDate) < end)
  }
  if (range === "last7") {
    const start = new Date(now.getTime() - 7 * 86400000)
    return orders.filter((o) => new Date(o.orderDate) >= start)
  }
  if (range === "thisMonth") {
    const start = new Date(now.getFullYear(), now.getMonth(), 1)
    return orders.filter((o) => new Date(o.orderDate) >= start)
  }
  if (range === "custom" && from && to) {
    return orders.filter((o) => o.orderDate >= from && o.orderDate <= to)
  }
  return orders
}

export async function getDashboardData(range: DateRangeKey = "all", from?: string, to?: string) {
  const allOrders = await getAllOrders()
  const orders = filterByRange(allOrders, range, from, to)
  const products = await listProducts()
  const settings = await getSettings()

  // Test orders must never distort operational KPIs or financial figures -
  // they are excluded here, at the metrics boundary, while still remaining
  // visible (clearly marked) in the raw Orders list elsewhere in the app.
  const realOrders = orders.filter((o) => !o.isTest)
  const testOrdersCount = orders.length - realOrders.length

  const statusCounts: Record<string, number> = {}
  for (const o of realOrders) statusCounts[o.status] = (statusCounts[o.status] ?? 0) + 1

  const kpis = computeKpis(realOrders)
  const financial = computeFinancialSummary(realOrders, products, settings.advertisingCost ?? null)

  return { orders: realOrders, statusCounts, kpis, financial, total: realOrders.length, testOrdersCount }
}

export async function getReportsData(range: DateRangeKey = "all", from?: string, to?: string) {
  const dashboard = await getDashboardData(range, from, to)
  const orders = dashboard.orders

  const byWilaya = groupCount(orders, (o) => o.wilaya)
  const byProduct = groupCount(orders, (o) => o.productSummary.split(" × ")[0])
  const bySource = groupCount(orders, (o) => o.source ?? "غير محدد")

  return { ...dashboard, byWilaya, byProduct, bySource }
}

function groupCount(orders: Order[], key: (o: Order) => string) {
  const map = new Map<string, number>()
  for (const o of orders) {
    const k = key(o) || "غير محدد"
    map.set(k, (map.get(k) ?? 0) + 1)
  }
  return [...map.entries()].map(([label, count]) => ({ label, count })).sort((a, b) => b.count - a.count)
}
