import "server-only"
import { randomUUID } from "crypto"
import { mutateStore, readStore } from "@/lib/data/json-store"
import type { SyncResult } from "@/lib/domain/types"

// Durable log of every sync run (preview and full), one entry per run.
// This is the CRM_SyncLogs support table referenced in the architecture spec.
const LOG_STORE = "CRM_SyncLogs"

// Per-connection snapshot of the last known hash for every order number seen
// during a FULL sync. This is what lets runFullSync report accurate
// created/updated/skipped counts across runs without ever touching the demo
// localRepository - the diff base is the connection's own sync history, not
// an unrelated data store.
const SNAPSHOT_STORE = "CRM_SyncSnapshots"

export interface SyncLogEntry extends SyncResult {
  id: string
  connectionId: string
  actor: string
}

export async function recordSyncLog(connectionId: string, actor: string, result: SyncResult): Promise<SyncLogEntry> {
  const entry: SyncLogEntry = { ...result, id: randomUUID(), connectionId, actor }
  await mutateStore<SyncLogEntry[]>(LOG_STORE, [], (list) => [entry, ...list].slice(0, 500))
  return entry
}

export async function listSyncLogs(connectionId?: string, limit = 50): Promise<SyncLogEntry[]> {
  const list = await readStore<SyncLogEntry[]>(LOG_STORE, [])
  return (connectionId ? list.filter((l) => l.connectionId === connectionId) : list).slice(0, limit)
}

type Snapshot = Record<string, string> // orderNumber -> hash of compared fields

export async function getSnapshot(connectionId: string): Promise<Snapshot> {
  const all = await readStore<Record<string, Snapshot>>(SNAPSHOT_STORE, {})
  return all[connectionId] ?? {}
}

export async function saveSnapshot(connectionId: string, snapshot: Snapshot): Promise<void> {
  await mutateStore<Record<string, Snapshot>>(SNAPSHOT_STORE, {}, (all) => ({ ...all, [connectionId]: snapshot }))
}
