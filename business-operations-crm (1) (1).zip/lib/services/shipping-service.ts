import "server-only"
import { randomUUID } from "crypto"
import { mutateStore, readStore } from "@/lib/data/json-store"
import { getOrder, changeOrderStatus } from "@/lib/services/order-service"
import { recordAudit } from "@/lib/services/audit-service"
import type { Shipment, ShipmentStatus } from "@/lib/domain/types"

const STORE_NAME = "CRM_Shipments"

export async function listShipments(): Promise<Shipment[]> {
  return readStore<Shipment[]>(STORE_NAME, [])
}

export async function getShipmentForOrder(orderNumber: string): Promise<Shipment | undefined> {
  const list = await listShipments()
  return list.find((s) => s.orderNumber === orderNumber)
}

/**
 * Manual shipping creation - works with no carrier API credentials.
 * A carrier adapter (e.g. Yalidine) can later populate trackingNumber via its own API;
 * until then this always records a real manual shipment record, never a fake carrier response.
 */
export async function createShipment(input: {
  orderNumber: string
  carrier: string
  trackingNumber?: string
  deliveryMode: Shipment["deliveryMode"]
  stopDeskName?: string
  shippingFee: number
  actor: string
}): Promise<Shipment> {
  const order = await getOrder(input.orderNumber)
  if (!order) throw new Error(`الطلب ${input.orderNumber} غير موجود`)

  const now = new Date().toISOString()
  const shipment: Shipment = {
    id: randomUUID(),
    orderNumber: input.orderNumber,
    carrier: input.carrier,
    trackingNumber: input.trackingNumber,
    deliveryMode: input.deliveryMode,
    stopDeskName: input.stopDeskName,
    shippingFee: input.shippingFee,
    status: "SHIPPED",
    createdAt: now,
    updatedAt: now,
  }

  await mutateStore<Shipment[]>(STORE_NAME, [], (list) => [...list, shipment])
  await changeOrderStatus(input.orderNumber, "SHIPPED", input.actor, `شحنة عبر ${input.carrier}`)
  await recordAudit(input.actor, "SHIPMENT_CREATED", "shipment", shipment.id, input.carrier)

  return shipment
}

export async function updateShipmentStatus(
  id: string,
  status: ShipmentStatus,
  actor: string,
): Promise<Shipment> {
  const updated = await mutateStore<Shipment[]>(STORE_NAME, [], (list) =>
    list.map((s) =>
      s.id === id
        ? {
            ...s,
            status,
            updatedAt: new Date().toISOString(),
            deliveredDate: status === "DELIVERED" ? new Date().toISOString() : s.deliveredDate,
            returnedDate: status === "RETURNED" ? new Date().toISOString() : s.returnedDate,
          }
        : s,
    ),
  )
  const shipment = updated.find((s) => s.id === id)
  if (!shipment) throw new Error("الشحنة غير موجودة")

  const orderStatusMap: Record<ShipmentStatus, string | null> = {
    PENDING: null,
    SHIPPED: "SHIPPED",
    IN_TRANSIT: "IN_TRANSIT",
    DELIVERED: "DELIVERED",
    RETURNED: "RETURNED",
    FAILED: null,
  }
  const orderStatus = orderStatusMap[status]
  if (orderStatus) {
    await changeOrderStatus(shipment.orderNumber, orderStatus as any, actor)
  }
  await recordAudit(actor, "SHIPMENT_STATUS_CHANGE", "shipment", id, status)

  return shipment
}
