import "server-only"
import { createHash } from "crypto"
import { readTabValues, testConnection as testGoogleConnection, listTabs as listGoogleTabs } from "@/lib/data/google-sheets-client"
import { rowToOrder } from "@/lib/data/google-sheets-repository"
import { autoMapHeaders, validateMapping } from "@/lib/data/sheet-mapping"
import { getConnection, updateConnection } from "@/lib/data/connection-store"
import { recordAudit } from "@/lib/services/audit-service"
import { getSnapshot, saveSnapshot, recordSyncLog } from "@/lib/services/sync-log-service"
import type { Order, SyncResult } from "@/lib/domain/types"

export async function testConnectionById(connectionId: string) {
  const conn = await getConnection(connectionId)
  if (!conn) throw new Error("الاتصال غير موجود")
  return testGoogleConnection(conn.spreadsheetId)
}

export async function listTabsForConnection(connectionId: string) {
  const conn = await getConnection(connectionId)
  if (!conn) throw new Error("الاتصال غير موجود")
  return listGoogleTabs(conn.spreadsheetId)
}

export async function readHeadersAndAutoMap(connectionId: string, tab: string, headerRow = 1) {
  const conn = await getConnection(connectionId)
  if (!conn) throw new Error("الاتصال غير موجود")
  const values = await readTabValues(conn.spreadsheetId, tab)
  const headers = values[headerRow - 1] ?? []
  const auto = autoMapHeaders(headers)
  return { headers, ...auto }
}

async function loadSourceOrders(connectionId: string) {
  const conn = await getConnection(connectionId)
  if (!conn) throw new Error("الاتصال غير موجود")
  if (!conn.selectedOrdersTab) throw new Error("لم يتم اختيار تبويب الطلبات")
  const { valid, missing } = validateMapping(conn.mapping)
  if (!valid) throw new Error(`الربط غير مكتمل. حقول ناقصة: ${missing.join(", ")}`)

  const values = await readTabValues(conn.spreadsheetId, conn.selectedOrdersTab)
  const headerIdx = conn.headerRow - 1
  const headers = values[headerIdx] ?? []
  const rows = values.slice(headerIdx + 1)
  const orders = rows
    .map((row, i) => ({ row, order: rowToOrder(headers, row, conn.mapping, conn.headerRow + i + 1) }))
    .filter((r) => r.order.orderNumber)
  return { conn, orders }
}

// Fields compared to decide whether a row changed since the last sync. Kept
// small and explicit so "updated" always reflects a real, meaningful change.
const COMPARE_FIELDS = [
  "status",
  "customerName",
  "phoneNormalized",
  "wilaya",
  "commune",
  "address",
  "productSummary",
  "quantity",
  "total",
  "notes",
  "trackingNumber",
] as const

function hashOrder(order: Order): string {
  const subset: Record<string, unknown> = {}
  for (const f of COMPARE_FIELDS) subset[f] = (order as unknown as Record<string, unknown>)[f]
  return createHash("sha1").update(JSON.stringify(subset)).digest("hex")
}

function detectDuplicates(orders: { order: Order }[]) {
  const seen = new Map<string, number[]>()
  for (const { order } of orders) {
    if (!order.orderNumber) continue
    const list = seen.get(order.orderNumber) ?? []
    list.push(order.rowIndex ?? 0)
    seen.set(order.orderNumber, list)
  }
  return [...seen.entries()].filter(([, rows]) => rows.length > 1).map(([orderNumber, rows]) => ({ orderNumber, rows }))
}

/**
 * PREVIEW: read, map, validate, detect duplicates, and diff against the
 * connection's own last-sync snapshot. Writes nothing anywhere - safe to run
 * repeatedly before activating a connection.
 */
export async function previewSync(connectionId: string): Promise<SyncResult> {
  const startedAt = new Date().toISOString()
  const { orders } = await loadSourceOrders(connectionId)

  const errors: SyncResult["errors"] = []
  for (const { order } of orders) {
    if (!order.phoneNormalized) {
      errors.push({ row: order.rowIndex ?? 0, message: `رقم هاتف غير صالح للطلب ${order.orderNumber}` })
    }
  }
  const duplicates = detectDuplicates(orders)
  const duplicateNumbers = new Set(duplicates.map((d) => d.orderNumber))

  const snapshot = await getSnapshot(connectionId)
  let created = 0
  let updated = 0
  let skipped = 0
  for (const { order } of orders) {
    if (duplicateNumbers.has(order.orderNumber)) continue
    const previousHash = snapshot[order.orderNumber]
    if (!previousHash) created++
    else if (previousHash !== hashOrder(order)) updated++
    else skipped++
  }

  return {
    mode: "PREVIEW",
    rowsScanned: orders.length,
    created,
    updated,
    skipped,
    errors,
    duplicates,
    startedAt,
    finishedAt: new Date().toISOString(),
  }
}

/**
 * FULL SYNC: actually persists every real order through the active
 * DataRepository (Google Sheets when connected, local demo store only
 * before any real spreadsheet is connected), by stable order number. A
 * connection can only be fully synced while it is the ACTIVE source, so this
 * never silently writes to a repository other than the one actually in use.
 */
export async function runFullSync(connectionId: string, actor: string): Promise<SyncResult> {
  const startedAt = new Date().toISOString()
  const { conn, orders } = await loadSourceOrders(connectionId)
  if (!conn.active) {
    throw new Error("يجب تفعيل مصدر البيانات قبل تشغيل المزامنة الكاملة")
  }

  const { getRepository } = await import("@/lib/data/repository-provider")
  const repo = await getRepository()

  let created = 0
  let updated = 0
  let skipped = 0
  const errors: SyncResult["errors"] = []
  const seen = new Set<string>()
  const duplicateRows = new Map<string, number[]>()
  const previousSnapshot = await getSnapshot(connectionId)
  const nextSnapshot: Record<string, string> = { ...previousSnapshot }

  for (const { order } of orders) {
    try {
      if (!order.orderNumber) {
        errors.push({ row: order.rowIndex ?? 0, message: "رقم الطلب مفقود، تم تجاهل الصف" })
        continue
      }
      if (seen.has(order.orderNumber)) {
        const rows = duplicateRows.get(order.orderNumber) ?? []
        rows.push(order.rowIndex ?? 0)
        duplicateRows.set(order.orderNumber, rows)
        skipped++
        continue
      }
      if (!order.phoneNormalized) {
        errors.push({ row: order.rowIndex ?? 0, message: `رقم هاتف غير صالح للطلب ${order.orderNumber}` })
        continue
      }
      seen.add(order.orderNumber)

      const hash = hashOrder(order)
      const previousHash = previousSnapshot[order.orderNumber]

      if (!previousHash) {
        const existing = await repo.findOrderByNumber(order.orderNumber)
        if (existing) {
          // Already present in the repository (e.g. re-running sync after a
          // partial failure) - treat as update, never as a duplicate create.
          await repo.updateOrder(order.orderNumber, order)
          updated++
        } else {
          await repo.createOrder(order)
          created++
        }
      } else if (previousHash !== hash) {
        await repo.updateOrder(order.orderNumber, order)
        updated++
      } else {
        skipped++
      }
      nextSnapshot[order.orderNumber] = hash
    } catch (err) {
      errors.push({ row: order.rowIndex ?? 0, message: err instanceof Error ? err.message : "خطأ غير معروف" })
    }
  }

  await saveSnapshot(connectionId, nextSnapshot)

  const result: SyncResult = {
    mode: "FULL",
    rowsScanned: orders.length,
    created,
    updated,
    skipped,
    errors,
    duplicates: [...duplicateRows.entries()].map(([orderNumber, rows]) => ({ orderNumber, rows })),
    startedAt,
    finishedAt: new Date().toISOString(),
  }

  const summary = `تم إنشاء ${created}، تحديث ${updated}، تجاهل ${skipped}، أخطاء ${errors.length}`
  await updateConnection(conn.connectionId, {
    lastSyncAt: result.finishedAt,
    lastSyncStatus: errors.length > 0 && created === 0 && updated === 0 ? "ERROR" : "SUCCESS",
    lastSyncSummary: summary,
  })

  await recordSyncLog(conn.connectionId, actor, result)
  await recordAudit(actor, "SYNC_FULL", "connection", conn.connectionId, summary)

  return result
}
