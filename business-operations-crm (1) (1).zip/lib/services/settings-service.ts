import "server-only"
import { readStore, writeStore } from "@/lib/data/json-store"

const STORE_NAME = "CRM_Settings"

export interface CrmSettings {
  businessName: string
  advertisingCost: number | null
  tiktokTestMode: boolean
  notificationsEnabled: boolean
}

const DEFAULT_SETTINGS: CrmSettings = {
  businessName: "متجري",
  advertisingCost: null,
  tiktokTestMode: true,
  notificationsEnabled: true,
}

export async function getSettings(): Promise<CrmSettings> {
  return readStore<CrmSettings>(STORE_NAME, DEFAULT_SETTINGS)
}

export async function updateSettings(patch: Partial<CrmSettings>): Promise<CrmSettings> {
  const current = await getSettings()
  const next = { ...current, ...patch }
  await writeStore(STORE_NAME, next)
  return next
}
