import "server-only"
import { getRepository } from "@/lib/data/repository-provider"
import { assertTransition } from "@/lib/domain/order-state"
import { recordAudit } from "@/lib/services/audit-service"
import { recordOrderEvent } from "@/lib/services/order-events-service"
import type { Order, OrderStatus } from "@/lib/domain/types"

export interface OrderFilters {
  search?: string
  status?: OrderStatus
  product?: string
  wilaya?: string
  confirmation?: string
  delivery?: string
  dateFrom?: string
  dateTo?: string
  page?: number
  pageSize?: number
}

export async function listOrders(filters: OrderFilters = {}): Promise<{ orders: Order[]; total: number }> {
  const repo = await getRepository()
  let orders = await repo.listOrders()

  if (filters.search) {
    const q = filters.search.trim().toLowerCase()
    orders = orders.filter(
      (o) =>
        o.orderNumber.toLowerCase().includes(q) ||
        o.customerName.toLowerCase().includes(q) ||
        o.phoneNormalized.includes(q) ||
        o.phoneRaw.includes(q),
    )
  }
  if (filters.status) orders = orders.filter((o) => o.status === filters.status)
  if (filters.product) orders = orders.filter((o) => o.productSummary.includes(filters.product!))
  if (filters.wilaya) orders = orders.filter((o) => o.wilaya === filters.wilaya)
  if (filters.dateFrom) orders = orders.filter((o) => o.orderDate >= filters.dateFrom!)
  if (filters.dateTo) orders = orders.filter((o) => o.orderDate <= filters.dateTo!)

  const total = orders.length
  const page = filters.page ?? 1
  const pageSize = filters.pageSize ?? 20
  const start = (page - 1) * pageSize
  orders = orders.slice(start, start + pageSize)

  return { orders, total }
}

export async function getOrder(orderNumber: string): Promise<Order | undefined> {
  const repo = await getRepository()
  return repo.findOrderByNumber(orderNumber)
}

export async function getAllOrders(): Promise<Order[]> {
  const repo = await getRepository()
  return repo.listOrders()
}

export async function changeOrderStatus(
  orderNumber: string,
  toStatus: OrderStatus,
  actor: string,
  note?: string,
): Promise<Order> {
  const repo = await getRepository()
  const existing = await repo.findOrderByNumber(orderNumber)
  if (!existing) throw new Error(`الطلب ${orderNumber} غير موجود`)
  assertTransition(existing.status, toStatus)

  const patch: Partial<Order> = { status: toStatus }
  if (toStatus === "CONFIRMED") patch.confirmationDate = new Date().toISOString()

  const updated = await repo.updateOrder(orderNumber, patch)

  await recordOrderEvent({
    orderNumber,
    type: "STATUS_CHANGE",
    fromStatus: existing.status,
    toStatus,
    actor,
    note,
  })
  await recordAudit(actor, "ORDER_STATUS_CHANGE", "order", orderNumber, `${existing.status} -> ${toStatus}`)

  return updated
}

export async function updateOrderFields(orderNumber: string, patch: Partial<Order>, actor: string): Promise<Order> {
  const repo = await getRepository()
  const updated = await repo.updateOrder(orderNumber, patch)
  await recordAudit(actor, "ORDER_FIELD_UPDATE", "order", orderNumber, JSON.stringify(patch))
  return updated
}

export function getUniqueWilayas(orders: Order[]): string[] {
  return [...new Set(orders.map((o) => o.wilaya))].filter(Boolean).sort()
}

export function getUniqueProducts(orders: Order[]): string[] {
  return [...new Set(orders.flatMap((o) => o.lines.map((l) => l.productName)))].filter(Boolean).sort()
}
