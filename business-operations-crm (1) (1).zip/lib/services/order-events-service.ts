import "server-only"
import { randomUUID } from "crypto"
import { mutateStore, readStore } from "@/lib/data/json-store"
import type { OrderEvent } from "@/lib/domain/types"

const STORE_NAME = "CRM_OrderEvents"

export async function recordOrderEvent(input: Omit<OrderEvent, "id" | "timestamp">): Promise<OrderEvent> {
  const event: OrderEvent = { ...input, id: randomUUID(), timestamp: new Date().toISOString() }
  await mutateStore<OrderEvent[]>(STORE_NAME, [], (list) => [event, ...list])
  return event
}

export async function listOrderEvents(orderNumber: string): Promise<OrderEvent[]> {
  const list = await readStore<OrderEvent[]>(STORE_NAME, [])
  return list.filter((e) => e.orderNumber === orderNumber).sort((a, b) => (a.timestamp < b.timestamp ? 1 : -1))
}
