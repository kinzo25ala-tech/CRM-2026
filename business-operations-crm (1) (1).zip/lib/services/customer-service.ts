import "server-only"
import { mutateStore, readStore } from "@/lib/data/json-store"
import { getAllOrders } from "@/lib/services/order-service"
import type { Customer, Order } from "@/lib/domain/types"

// Customer notes/blacklist are CRM-owned (no safe column in the master sheet).
const NOTES_STORE = "CRM_CustomerNotes"

interface CustomerNote {
  phoneNormalized: string
  notes?: string
  blacklisted: boolean
}

function buildCustomerFromOrders(phone: string, orders: Order[]): Customer {
  const customerOrders = orders.filter((o) => o.phoneNormalized === phone)
  const sorted = [...customerOrders].sort((a, b) => (a.orderDate < b.orderDate ? -1 : 1))
  const latest = sorted[sorted.length - 1]
  return {
    phoneNormalized: phone,
    name: latest?.customerName ?? "",
    wilaya: latest?.wilaya,
    commune: latest?.commune,
    address: latest?.address,
    ordersCount: customerOrders.length,
    confirmedCount: customerOrders.filter((o) =>
      ["CONFIRMED", "READY_TO_SHIP", "SHIPPED", "IN_TRANSIT", "DELIVERED"].includes(o.status),
    ).length,
    deliveredCount: customerOrders.filter((o) => o.status === "DELIVERED").length,
    cancelledCount: customerOrders.filter((o) => o.status === "CANCELLED").length,
    returnedCount: customerOrders.filter((o) => o.status === "RETURNED").length,
    blacklisted: false,
    firstOrderAt: sorted[0]?.orderDate,
    lastOrderAt: latest?.orderDate,
  }
}

export async function listCustomers(search?: string): Promise<Customer[]> {
  const orders = await getAllOrders()
  const notes = await readStore<CustomerNote[]>(NOTES_STORE, [])
  const phones = [...new Set(orders.map((o) => o.phoneNormalized).filter(Boolean))]

  let customers = phones.map((phone) => {
    const base = buildCustomerFromOrders(phone, orders)
    const note = notes.find((n) => n.phoneNormalized === phone)
    return { ...base, notes: note?.notes, blacklisted: note?.blacklisted ?? false }
  })

  if (search) {
    const q = search.trim().toLowerCase()
    customers = customers.filter((c) => c.name.toLowerCase().includes(q) || c.phoneNormalized.includes(q))
  }

  return customers.sort((a, b) => (a.lastOrderAt! < b.lastOrderAt! ? 1 : -1))
}

export async function getCustomer(phone: string): Promise<{ customer: Customer; orders: Order[] } | undefined> {
  const orders = await getAllOrders()
  const customerOrders = orders.filter((o) => o.phoneNormalized === phone)
  if (customerOrders.length === 0) return undefined
  const notes = await readStore<CustomerNote[]>(NOTES_STORE, [])
  const note = notes.find((n) => n.phoneNormalized === phone)
  const base = buildCustomerFromOrders(phone, orders)
  return {
    customer: { ...base, notes: note?.notes, blacklisted: note?.blacklisted ?? false },
    orders: customerOrders.sort((a, b) => (a.orderDate < b.orderDate ? 1 : -1)),
  }
}

export async function setCustomerNotes(phone: string, notes: string): Promise<void> {
  await mutateStore<CustomerNote[]>(NOTES_STORE, [], (list) => {
    const idx = list.findIndex((n) => n.phoneNormalized === phone)
    if (idx === -1) return [...list, { phoneNormalized: phone, notes, blacklisted: false }]
    const copy = [...list]
    copy[idx] = { ...copy[idx], notes }
    return copy
  })
}

export async function setCustomerBlacklist(phone: string, blacklisted: boolean): Promise<void> {
  await mutateStore<CustomerNote[]>(NOTES_STORE, [], (list) => {
    const idx = list.findIndex((n) => n.phoneNormalized === phone)
    if (idx === -1) return [...list, { phoneNormalized: phone, blacklisted }]
    const copy = [...list]
    copy[idx] = { ...copy[idx], blacklisted }
    return copy
  })
}
