import "server-only"
import { randomUUID } from "crypto"
import { mutateStore, readStore } from "@/lib/data/json-store"
import type { CallAttempt, CallResult } from "@/lib/domain/types"

const STORE_NAME = "CRM_CallAttempts"

export async function listCallAttemptsForOrder(orderNumber: string): Promise<CallAttempt[]> {
  const list = await readStore<CallAttempt[]>(STORE_NAME, [])
  return list.filter((c) => c.orderNumber === orderNumber).sort((a, b) => (a.timestamp < b.timestamp ? 1 : -1))
}

export async function recordCallAttempt(input: {
  orderNumber: string
  agent: string
  result: CallResult
  note?: string
  callbackAt?: string
}): Promise<CallAttempt> {
  return mutateStore<CallAttempt[]>(STORE_NAME, [], (list) => {
    const previousAttempts = list.filter((c) => c.orderNumber === input.orderNumber).length
    const attempt: CallAttempt = {
      id: randomUUID(),
      orderNumber: input.orderNumber,
      attemptNumber: previousAttempts + 1,
      agent: input.agent,
      result: input.result,
      note: input.note,
      timestamp: new Date().toISOString(),
      callbackAt: input.callbackAt,
    }
    return [...list, attempt]
  }).then((all) => all[all.length - 1])
}

export async function countAttemptsToday(orderNumber?: string): Promise<CallAttempt[]> {
  const list = await readStore<CallAttempt[]>(STORE_NAME, [])
  const today = new Date().toDateString()
  return list.filter((c) => new Date(c.timestamp).toDateString() === today && (!orderNumber || c.orderNumber === orderNumber))
}
