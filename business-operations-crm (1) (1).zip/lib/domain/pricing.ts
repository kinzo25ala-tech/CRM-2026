import type { Order, OrderLine, Product } from "./types"

export function lineTotal(line: OrderLine): number {
  return line.quantity * line.unitPrice
}

export function orderSubtotal(lines: OrderLine[]): number {
  return lines.reduce((sum, l) => sum + lineTotal(l), 0)
}

export function orderTotal(lines: OrderLine[], shippingFee: number): number {
  return orderSubtotal(lines) + (shippingFee || 0)
}

export function priceForQuantity(product: Product, quantity: number): number {
  if (!product.pricingTiers?.length) return product.price
  const applicable = [...product.pricingTiers]
    .sort((a, b) => a.minQty - b.minQty)
    .filter((t) => quantity >= t.minQty)
  return applicable.length ? applicable[applicable.length - 1].unitPrice : product.price
}

/** Estimated product cost for an order, only if product costs are known. Returns null if unknown. */
export function estimateOrderProductCost(order: Order, products: Product[]): number | null {
  let total = 0
  let anyKnown = false
  for (const line of order.lines) {
    const product = products.find(
      (p) => p.name === line.productName || p.sku === line.sku || p.aliases.includes(line.productName),
    )
    if (product?.cost != null) {
      total += product.cost * line.quantity
      anyKnown = true
    }
  }
  return anyKnown ? total : null
}

export interface FinancialSummary {
  revenue: number
  confirmedRevenue: number
  deliveredRevenue: number
  productCost: number | null
  shippingCost: number
  advertisingCost: number | null
  estimatedGrossResult: number | null
  estimatedNetResult: number | null
}

export function computeFinancialSummary(
  orders: Order[],
  products: Product[],
  advertisingCost: number | null,
): FinancialSummary {
  const revenue = orders.reduce((s, o) => s + o.total, 0)
  const confirmedRevenue = orders
    .filter((o) => ["CONFIRMED", "READY_TO_SHIP", "SHIPPED", "IN_TRANSIT", "DELIVERED"].includes(o.status))
    .reduce((s, o) => s + o.total, 0)
  const deliveredRevenue = orders.filter((o) => o.status === "DELIVERED").reduce((s, o) => s + o.total, 0)

  let productCost: number | null = 0
  let anyKnownCost = false
  for (const o of orders) {
    const c = estimateOrderProductCost(o, products)
    if (c != null) {
      productCost += c
      anyKnownCost = true
    }
  }
  if (!anyKnownCost) productCost = null

  const shippingCost = orders.reduce((s, o) => s + (o.shippingFee || 0), 0)

  const estimatedGrossResult =
    productCost != null ? deliveredRevenue - productCost - shippingCost : null
  const estimatedNetResult =
    estimatedGrossResult != null && advertisingCost != null ? estimatedGrossResult - advertisingCost : null

  return {
    revenue,
    confirmedRevenue,
    deliveredRevenue,
    productCost,
    shippingCost,
    advertisingCost,
    estimatedGrossResult,
    estimatedNetResult,
  }
}

export function computeKpis(orders: Order[]) {
  const total = orders.length || 1
  const confirmed = orders.filter((o) =>
    ["CONFIRMED", "READY_TO_SHIP", "SHIPPED", "IN_TRANSIT", "DELIVERED", "RETURNED"].includes(o.status),
  ).length
  const cancelled = orders.filter((o) => o.status === "CANCELLED").length
  const delivered = orders.filter((o) => o.status === "DELIVERED").length
  const returned = orders.filter((o) => o.status === "RETURNED").length
  const shippedOrMore = orders.filter((o) =>
    ["SHIPPED", "IN_TRANSIT", "DELIVERED", "RETURNED"].includes(o.status),
  ).length

  return {
    confirmationRate: confirmed / total,
    cancellationRate: cancelled / total,
    deliveryRate: shippedOrMore ? delivered / shippedOrMore : 0,
    returnRate: shippedOrMore ? returned / shippedOrMore : 0,
  }
}
