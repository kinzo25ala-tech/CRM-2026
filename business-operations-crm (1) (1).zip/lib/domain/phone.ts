// Algerian phone normalization.
// Canonical form: +213XXXXXXXXX (9 digits after country code, no leading 0)

export function normalizePhone(raw: string | undefined | null): string {
  if (!raw) return ""
  let digits = String(raw).trim().replace(/[^\d+]/g, "")

  // Strip a leading + sign for processing, remember if it existed
  digits = digits.replace(/^\+/, "")

  // Remove leading 00 (international prefix)
  if (digits.startsWith("00")) digits = digits.slice(2)

  // Already has country code 213
  if (digits.startsWith("213")) {
    digits = digits.slice(3)
  }

  // Remove a single leading 0 (local format 0XXXXXXXXX)
  if (digits.startsWith("0")) {
    digits = digits.slice(1)
  }

  // Keep only the last 9 digits (Algerian mobile/landline numbers are 9 digits after country code)
  digits = digits.slice(-9)

  if (digits.length !== 9) {
    // Not a valid Algerian number shape - return best-effort cleaned raw value
    return raw.trim()
  }

  return `+213${digits}`
}

export function isValidAlgerianPhone(raw: string | undefined | null): boolean {
  const normalized = normalizePhone(raw)
  return /^\+213[5-7]\d{8}$/.test(normalized)
}

export function formatPhoneForDisplay(normalized: string): string {
  if (!normalized.startsWith("+213")) return normalized
  const local = normalized.slice(4)
  return `0${local.slice(0, 3)} ${local.slice(3, 5)} ${local.slice(5, 7)} ${local.slice(7, 9)}`
}
