// Core domain types shared across the CRM.
// These map to columns in the master Google Sheet (Order) and to CRM_* support sheets.

export type OrderStatus =
  | "NEW"
  | "PENDING_CONFIRMATION"
  | "CALLED"
  | "CONFIRMED"
  | "POSTPONED"
  | "CANCELLED"
  | "READY_TO_SHIP"
  | "SHIPPED"
  | "IN_TRANSIT"
  | "DELIVERED"
  | "RETURNED"

export const ORDER_STATUS_LABELS_AR: Record<OrderStatus, string> = {
  NEW: "جديد",
  PENDING_CONFIRMATION: "في انتظار التأكيد",
  CALLED: "تم الاتصال",
  CONFIRMED: "مؤكد",
  POSTPONED: "مؤجل",
  CANCELLED: "ملغى",
  READY_TO_SHIP: "جاهز للشحن",
  SHIPPED: "تم الشحن",
  IN_TRANSIT: "قيد التوصيل",
  DELIVERED: "مسلم",
  RETURNED: "مرتجع",
}

export type DeliveryType = "HOME" | "STOP_DESK" | "UNKNOWN"

export const DELIVERY_TYPE_LABELS_AR: Record<DeliveryType, string> = {
  HOME: "منزل",
  STOP_DESK: "مكتب",
  UNKNOWN: "غير محدد",
}

export interface OrderLine {
  productName: string
  sku?: string
  quantity: number
  unitPrice: number
}

export interface TikTokAttribution {
  ttclid?: string
  ttp?: string
  fbclid?: string
  campaign?: string
  adGroup?: string
  ad?: string
  creative?: string
  source?: string
}

export interface Order {
  id: string // stable internal id, derived from orderNumber
  orderNumber: string // IMMUTABLE stable identity used for matching against the source sheet
  rowIndex?: number // 1-based row index in the source sheet (for targeted writes)
  orderDate: string // ISO date
  customerName: string
  phoneRaw: string
  phoneNormalized: string // +213...
  wilaya: string
  commune: string
  address?: string
  lines: OrderLine[]
  productSummary: string // human readable "product x qty"
  quantity: number
  deliveryType: DeliveryType
  shippingFee: number
  total: number
  status: OrderStatus
  callAttempts: number
  postponedUntil?: string
  confirmationDate?: string
  notes?: string
  trackingNumber?: string
  deliveryResult?: string
  deliveryNotes?: string
  source?: string
  attribution: TikTokAttribution
  createdAt: string
  updatedAt: string
  isTest?: boolean
}

export interface Customer {
  phoneNormalized: string // primary identity
  name: string
  wilaya?: string
  commune?: string
  address?: string
  ordersCount: number
  confirmedCount: number
  deliveredCount: number
  cancelledCount: number
  returnedCount: number
  notes?: string
  blacklisted: boolean
  firstOrderAt?: string
  lastOrderAt?: string
}

export interface Product {
  id: string
  name: string
  sku?: string
  aliases: string[]
  category?: string
  cost?: number
  price: number
  status: "ACTIVE" | "INACTIVE"
  pricingTiers?: { minQty: number; unitPrice: number }[]
  createdAt: string
  updatedAt: string
}

export interface InventoryRecord {
  productId: string
  currentStock: number
  reserved: number
  sold: number
  returned: number
  damaged: number
  updatedAt: string
}

export type ShipmentStatus = "PENDING" | "SHIPPED" | "IN_TRANSIT" | "DELIVERED" | "RETURNED" | "FAILED"

export interface Shipment {
  id: string
  orderNumber: string
  carrier: string
  trackingNumber?: string
  deliveryMode: DeliveryType
  stopDeskName?: string
  shippingFee: number
  status: ShipmentStatus
  deliveredDate?: string
  returnedDate?: string
  createdAt: string
  updatedAt: string
}

export type CallResult =
  | "CONFIRMED"
  | "NO_ANSWER"
  | "PHONE_OFF"
  | "WRONG_NUMBER"
  | "POSTPONED"
  | "CANCELLED"

export const CALL_RESULT_LABELS_AR: Record<CallResult, string> = {
  CONFIRMED: "تأكيد الطلب",
  NO_ANSWER: "لا يجيب",
  PHONE_OFF: "هاتف مغلق",
  WRONG_NUMBER: "رقم خاطئ",
  POSTPONED: "تأجيل",
  CANCELLED: "إلغاء",
}

export interface CallAttempt {
  id: string
  orderNumber: string
  attemptNumber: number
  agent: string
  result: CallResult
  note?: string
  timestamp: string
  callbackAt?: string
}

export type Role = "OWNER" | "MANAGER" | "CONFIRMATION_AGENT" | "SHIPPING_AGENT" | "VIEWER"

export interface CrmUser {
  id: string
  username: string
  name: string
  role: Role
  passwordHash: string
  passwordSalt: string
  active: boolean
  createdAt: string
}

export interface AuditLogEntry {
  id: string
  actor: string
  action: string
  entity: string
  entityId: string
  details?: string
  timestamp: string
}

export interface OrderEvent {
  id: string
  orderNumber: string
  type: string
  fromStatus?: OrderStatus
  toStatus?: OrderStatus
  actor: string
  note?: string
  timestamp: string
}

export type SyncMode = "PREVIEW" | "FULL"

export interface ColumnMapping {
  [crmField: string]: string // crmField -> source header name
}

export interface SheetConnection {
  connectionId: string
  name: string
  spreadsheetId: string
  active: boolean
  selectedOrdersTab?: string
  headerRow: number
  mapping: ColumnMapping
  syncMode: SyncMode
  lastSyncAt?: string
  lastSyncStatus?: "SUCCESS" | "ERROR" | "NEVER"
  lastSyncSummary?: string
  createdAt: string
  updatedAt: string
}

export interface SyncResult {
  mode: SyncMode
  rowsScanned: number
  created: number
  updated: number
  skipped: number
  errors: { row: number; message: string }[]
  duplicates: { orderNumber: string; rows: number[] }[]
  startedAt: string
  finishedAt: string
}

export type TikTokEventType = "CONFIRM" | "PURCHASE"

export interface TikTokOutboxEvent {
  id: string
  orderNumber: string
  eventType: TikTokEventType
  idempotencyKey: string
  status: "PENDING" | "SENT" | "FAILED" | "STUBBED"
  payload: Record<string, unknown>
  attempts: number
  lastError?: string
  createdAt: string
  sentAt?: string
}
