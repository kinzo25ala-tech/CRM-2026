import type { OrderStatus } from "./types"

// Allowed status transitions. Enforced server-side on every write.
const TRANSITIONS: Record<OrderStatus, OrderStatus[]> = {
  NEW: ["PENDING_CONFIRMATION", "CANCELLED"],
  PENDING_CONFIRMATION: ["CALLED", "CONFIRMED", "POSTPONED", "CANCELLED"],
  CALLED: ["CONFIRMED", "POSTPONED", "CANCELLED", "PENDING_CONFIRMATION"],
  POSTPONED: ["CALLED", "CONFIRMED", "CANCELLED", "PENDING_CONFIRMATION"],
  CONFIRMED: ["READY_TO_SHIP", "CANCELLED"],
  READY_TO_SHIP: ["SHIPPED", "CANCELLED"],
  SHIPPED: ["IN_TRANSIT", "DELIVERED", "RETURNED"],
  IN_TRANSIT: ["DELIVERED", "RETURNED"],
  DELIVERED: ["RETURNED"],
  RETURNED: [],
  CANCELLED: ["PENDING_CONFIRMATION"],
}

export function canTransition(from: OrderStatus, to: OrderStatus): boolean {
  if (from === to) return true
  return TRANSITIONS[from]?.includes(to) ?? false
}

export function assertTransition(from: OrderStatus, to: OrderStatus) {
  if (!canTransition(from, to)) {
    throw new Error(`لا يمكن تغيير حالة الطلب من "${from}" إلى "${to}"`)
  }
}

export const ACTIVE_CONFIRMATION_STATUSES: OrderStatus[] = ["NEW", "PENDING_CONFIRMATION", "CALLED", "POSTPONED"]
export const TERMINAL_STATUSES: OrderStatus[] = ["CANCELLED", "DELIVERED", "RETURNED"]
