import "server-only"
import { randomUUID } from "crypto"
import { mutateStore, readStore } from "@/lib/data/json-store"
import type { SheetConnection } from "@/lib/domain/types"

// Durable CRM configuration store for Google Sheets connection metadata.
// Design: this store is a pluggable backend behind a stable API. Today, with no
// bootstrap spreadsheet configured, it persists to a local JSON file
// (.data/CRM_Connections.json). Once CRM_CONFIG_SPREADSHEET_ID and Google service
// account credentials are provided, the same records should live in a
// "CRM_Connections" tab inside that bootstrap spreadsheet instead - no caller of
// this module needs to change, only the implementation of the functions below.
// Service-account private keys are NEVER stored here - only spreadsheet ids/mapping.

const STORE_NAME = "CRM_Connections"

export async function listConnections(): Promise<SheetConnection[]> {
  return readStore<SheetConnection[]>(STORE_NAME, [])
}

export async function getActiveConnection(): Promise<SheetConnection | undefined> {
  const list = await listConnections()
  return list.find((c) => c.active)
}

export async function getConnection(id: string): Promise<SheetConnection | undefined> {
  const list = await listConnections()
  return list.find((c) => c.connectionId === id)
}

export async function createConnection(input: {
  name: string
  spreadsheetId: string
}): Promise<SheetConnection> {
  return mutateStore<SheetConnection[]>(STORE_NAME, [], (list) => {
    const now = new Date().toISOString()
    const conn: SheetConnection = {
      connectionId: randomUUID(),
      name: input.name,
      spreadsheetId: input.spreadsheetId,
      active: false,
      headerRow: 1,
      mapping: {},
      syncMode: "PREVIEW",
      lastSyncStatus: "NEVER",
      createdAt: now,
      updatedAt: now,
    }
    return [...list, conn]
  }).then((all) => all[all.length - 1])
}

export async function updateConnection(id: string, patch: Partial<SheetConnection>): Promise<SheetConnection> {
  const list = await mutateStore<SheetConnection[]>(STORE_NAME, [], (list) =>
    list.map((c) => (c.connectionId === id ? { ...c, ...patch, updatedAt: new Date().toISOString() } : c)),
  )
  return list.find((c) => c.connectionId === id)!
}

export async function setActiveConnection(id: string): Promise<void> {
  await mutateStore<SheetConnection[]>(STORE_NAME, [], (list) =>
    list.map((c) => ({ ...c, active: c.connectionId === id, updatedAt: new Date().toISOString() })),
  )
}

export async function deactivateConnection(id: string): Promise<void> {
  await mutateStore<SheetConnection[]>(STORE_NAME, [], (list) =>
    list.map((c) => (c.connectionId === id ? { ...c, active: false, updatedAt: new Date().toISOString() } : c)),
  )
}
