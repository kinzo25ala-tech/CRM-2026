import type { Order } from "@/lib/domain/types"

// Abstraction over the master order data source.
// Today this is backed by lib/data/local-repository.ts (a JSON file that mimics the
// shape/behavior of the master Google Sheet). Once a Google Sheets connection is
// configured in Settings -> مصادر البيانات, GoogleSheetsRepository (lib/data/google-sheets-repository.ts)
// implements the exact same interface and can be swapped in without touching any
// service or page code.
export interface DataRepository {
  /** List all orders currently in the master source. */
  listOrders(): Promise<Order[]>
  /** Find a single order by its immutable order number. */
  findOrderByNumber(orderNumber: string): Promise<Order | undefined>
  /** Insert a brand new order row into the master source. Returns the created order with rowIndex set. */
  createOrder(order: Order): Promise<Order>
  /** Update only the given fields of an existing order, targeting its specific row/cells. */
  updateOrder(orderNumber: string, patch: Partial<Order>): Promise<Order>
  /** Human readable identifier of the underlying source, for display in Settings. */
  describeSource(): Promise<{ kind: "LOCAL" | "GOOGLE_SHEETS"; label: string }>
}
