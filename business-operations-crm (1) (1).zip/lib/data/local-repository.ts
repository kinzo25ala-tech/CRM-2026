import "server-only"
import { randomUUID } from "crypto"
import { mutateStore, readStore } from "@/lib/data/json-store"
import { normalizePhone } from "@/lib/domain/phone"
import { orderTotal } from "@/lib/domain/pricing"
import type { DataRepository } from "@/lib/data/repository"
import type { Order } from "@/lib/domain/types"

const STORE_NAME = "MasterOrders"

const WILAYAS = ["الجزائر", "وهران", "قسنطينة", "سطيف", "عنابة", "باتنة", "بليدة", "تلمسان"]
const PRODUCTS = [
  { name: "شاحن سيارة سريع", price: 2500 },
  { name: "سماعة بلوتوث", price: 3200 },
  { name: "ساعة ذكية", price: 5900 },
  { name: "بطارية محمولة 20000mAh", price: 4200 },
]
const STATUSES: Order["status"][] = [
  "NEW",
  "PENDING_CONFIRMATION",
  "CALLED",
  "CONFIRMED",
  "POSTPONED",
  "CANCELLED",
  "READY_TO_SHIP",
  "SHIPPED",
  "IN_TRANSIT",
  "DELIVERED",
  "RETURNED",
]

function seedOrders(): Order[] {
  const now = Date.now()
  const orders: Order[] = []
  for (let i = 1; i <= 42; i++) {
    const product = PRODUCTS[i % PRODUCTS.length]
    const qty = 1 + (i % 3)
    const shippingFee = 600
    const status = STATUSES[i % STATUSES.length]
    const daysAgo = i % 21
    const orderDate = new Date(now - daysAgo * 86400000).toISOString()
    const phoneLocal = `05${(50000000 + i * 137).toString().slice(0, 8)}`
    orders.push({
      id: randomUUID(),
      orderNumber: `ORD-${1000 + i}`,
      orderDate,
      customerName: `عميل ${i}`,
      phoneRaw: phoneLocal,
      phoneNormalized: normalizePhone(phoneLocal),
      wilaya: WILAYAS[i % WILAYAS.length],
      commune: `بلدية ${(i % 5) + 1}`,
      address: `حي ${i}، شارع رقم ${(i % 10) + 1}`,
      lines: [{ productName: product.name, quantity: qty, unitPrice: product.price }],
      productSummary: `${product.name} × ${qty}`,
      quantity: qty,
      deliveryType: i % 2 === 0 ? "HOME" : "STOP_DESK",
      shippingFee,
      total: orderTotal([{ productName: product.name, quantity: qty, unitPrice: product.price }], shippingFee),
      status,
      callAttempts: status === "NEW" ? 0 : 1 + (i % 3),
      notes: i % 7 === 0 ? "طلب يحتاج متابعة خاصة" : undefined,
      source: i % 4 === 0 ? "TikTok Ads" : i % 4 === 1 ? "Facebook Ads" : "طلب مباشر",
      attribution: {
        ttclid: i % 4 === 0 ? `ttclid_${i}` : undefined,
        campaign: i % 4 === 0 ? "حملة الشتاء" : undefined,
      },
      createdAt: orderDate,
      updatedAt: orderDate,
      isTest: false,
    })
  }
  return orders
}

async function seedIfEmpty(): Promise<Order[]> {
  return mutateStore<Order[]>(STORE_NAME, [], (orders) => (orders.length > 0 ? orders : seedOrders()))
}

export class LocalRepository implements DataRepository {
  async listOrders(): Promise<Order[]> {
    await seedIfEmpty()
    const orders = await readStore<Order[]>(STORE_NAME, [])
    return [...orders].sort((a, b) => (a.orderDate < b.orderDate ? 1 : -1))
  }

  async findOrderByNumber(orderNumber: string): Promise<Order | undefined> {
    const orders = await this.listOrders()
    return orders.find((o) => o.orderNumber === orderNumber)
  }

  async createOrder(order: Order): Promise<Order> {
    return mutateStore<Order[]>(STORE_NAME, [], (orders) => {
      if (orders.some((o) => o.orderNumber === order.orderNumber)) {
        throw new Error(`رقم الطلب ${order.orderNumber} موجود مسبقاً`)
      }
      return [...orders, order]
    }).then((all) => all.find((o) => o.orderNumber === order.orderNumber)!)
  }

  async updateOrder(orderNumber: string, patch: Partial<Order>): Promise<Order> {
    const updated = await mutateStore<Order[]>(STORE_NAME, [], (orders) => {
      const idx = orders.findIndex((o) => o.orderNumber === orderNumber)
      if (idx === -1) throw new Error(`الطلب ${orderNumber} غير موجود`)
      const next = { ...orders[idx], ...patch, updatedAt: new Date().toISOString() }
      const copy = [...orders]
      copy[idx] = next
      return copy
    })
    return updated.find((o) => o.orderNumber === orderNumber)!
  }

  async describeSource() {
    return { kind: "LOCAL" as const, label: "بيانات محلية تجريبية (لم يتم ربط Google Sheets بعد)" }
  }
}

export const localRepository = new LocalRepository()
