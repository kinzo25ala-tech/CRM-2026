import { promises as fs } from "fs"
import path from "path"

// Generic server-only JSON file persistence.
// This backs the CRM_* support "sheets" (CRM_Users, CRM_Settings, CRM_CallAttempts, etc.)
// until they are migrated to live inside the Google Spreadsheet (see lib/data/connection-store.ts).
// Never import this from client components.

const DATA_DIR = path.join(process.cwd(), ".data")

async function ensureDir() {
  await fs.mkdir(DATA_DIR, { recursive: true })
}

function filePathFor(name: string) {
  return path.join(DATA_DIR, `${name}.json`)
}

export async function readStore<T>(name: string, fallback: T): Promise<T> {
  try {
    await ensureDir()
    const raw = await fs.readFile(filePathFor(name), "utf-8")
    return JSON.parse(raw) as T
  } catch {
    return fallback
  }
}

const locks = new Map<string, Promise<unknown>>()

export async function writeStore<T>(name: string, data: T): Promise<void> {
  await ensureDir()
  await fs.writeFile(filePathFor(name), JSON.stringify(data, null, 2), "utf-8")
}

/** Read-modify-write with a simple in-process lock to avoid concurrent write races. */
export async function mutateStore<T>(name: string, fallback: T, mutator: (data: T) => T | Promise<T>): Promise<T> {
  const prev = locks.get(name) ?? Promise.resolve()
  let result!: T
  const next = prev
    .catch(() => {})
    .then(async () => {
      const current = await readStore<T>(name, fallback)
      result = await mutator(current)
      await writeStore(name, result)
      return result
    })
  locks.set(name, next)
  await next
  return result
}
