import "server-only"
import { getActiveConnection } from "@/lib/data/connection-store"
import { hasGoogleCredentials } from "@/lib/data/google-sheets-client"
import { GoogleSheetsRepository } from "@/lib/data/google-sheets-repository"
import { localRepository } from "@/lib/data/local-repository"
import type { DataRepository } from "@/lib/data/repository"
import { validateMapping } from "@/lib/data/sheet-mapping"

/**
 * Resolves the active DataRepository. Falls back to the local JSON-backed
 * repository (safe demo data) whenever Google credentials or an active,
 * fully-mapped connection are not available - the CRM stays fully usable
 * before a real spreadsheet is connected.
 */
export async function getRepository(): Promise<DataRepository> {
  if (!hasGoogleCredentials()) return localRepository

  const conn = await getActiveConnection()
  if (!conn || !conn.selectedOrdersTab) return localRepository

  const { valid } = validateMapping(conn.mapping)
  if (!valid) return localRepository

  return new GoogleSheetsRepository(conn.spreadsheetId, conn.selectedOrdersTab, conn.mapping, conn.headerRow)
}

export async function isUsingRealSheet(): Promise<boolean> {
  const repo = await getRepository()
  const desc = await repo.describeSource()
  return desc.kind === "GOOGLE_SHEETS"
}
