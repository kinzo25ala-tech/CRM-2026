import "server-only"
import { readTabValues, updateRowCells, appendRow, withRetry } from "@/lib/data/google-sheets-client"
import { normalizePhone } from "@/lib/domain/phone"
import { orderTotal } from "@/lib/domain/pricing"
import type { DataRepository } from "@/lib/data/repository"
import type { ColumnMapping, Order, OrderStatus } from "@/lib/domain/types"

// Column letters A, B, C... for a given zero-based header index.
function columnLetter(index: number): string {
  let n = index + 1
  let letter = ""
  while (n > 0) {
    const rem = (n - 1) % 26
    letter = String.fromCharCode(65 + rem) + letter
    n = Math.floor((n - 1) / 26)
  }
  return letter
}

const STATUS_LABEL_TO_CODE: Record<string, OrderStatus> = {
  جديد: "NEW",
  "في انتظار التأكيد": "PENDING_CONFIRMATION",
  "تم الاتصال": "CALLED",
  مؤكد: "CONFIRMED",
  مؤجل: "POSTPONED",
  ملغى: "CANCELLED",
  "جاهز للشحن": "READY_TO_SHIP",
  "تم الشحن": "SHIPPED",
  "قيد التوصيل": "IN_TRANSIT",
  مسلم: "DELIVERED",
  مرتجع: "RETURNED",
}
const STATUS_CODE_TO_LABEL = Object.fromEntries(Object.entries(STATUS_LABEL_TO_CODE).map(([k, v]) => [v, k]))

export function rowToOrder(headers: string[], row: string[], mapping: ColumnMapping, rowIndex: number): Order {
  const get = (field: string) => {
    const header = mapping[field]
    if (!header) return ""
    const idx = headers.indexOf(header)
    return idx >= 0 ? (row[idx] ?? "") : ""
  }
  const quantity = Number(get("quantity")) || 1
  const unitPrice = Number(get("unitPrice")) || 0
  const shippingFee = Number(get("shippingFee")) || 0
  const total = Number(get("total")) || orderTotal([{ productName: get("product"), quantity, unitPrice }], shippingFee)
  const now = new Date().toISOString()

  return {
    id: get("orderNumber") || `row-${rowIndex}`,
    orderNumber: get("orderNumber"),
    rowIndex,
    orderDate: get("orderDate") || now,
    customerName: get("customerName"),
    phoneRaw: get("phone"),
    phoneNormalized: normalizePhone(get("phone")),
    wilaya: get("wilaya"),
    commune: get("commune"),
    address: get("address"),
    lines: [{ productName: get("product"), quantity, unitPrice }],
    productSummary: `${get("product")} × ${quantity}`,
    quantity,
    deliveryType: get("deliveryType")?.includes("مكتب") ? "STOP_DESK" : "HOME",
    shippingFee,
    total,
    status: STATUS_LABEL_TO_CODE[get("status")] ?? "NEW",
    callAttempts: Number(get("callAttempts")) || 0,
    postponedUntil: get("postponedUntil") || undefined,
    confirmationDate: get("confirmationDate") || undefined,
    notes: get("notes") || undefined,
    trackingNumber: get("trackingNumber") || undefined,
    deliveryResult: get("deliveryResult") || undefined,
    deliveryNotes: get("deliveryNotes") || undefined,
    source: get("source") || undefined,
    attribution: {
      ttclid: get("ttclid") || undefined,
      ttp: get("ttp") || undefined,
      fbclid: get("fbclid") || undefined,
      campaign: get("campaign") || undefined,
    },
    createdAt: now,
    updatedAt: now,
  }
}

export class GoogleSheetsRepository implements DataRepository {
  constructor(
    private spreadsheetId: string,
    private tab: string,
    private mapping: ColumnMapping,
    private headerRow: number,
  ) {}

  private async loadRaw(): Promise<{ headers: string[]; rows: string[][] }> {
    const values = await withRetry(() => readTabValues(this.spreadsheetId, this.tab))
    const headerIdx = this.headerRow - 1
    const headers = values[headerIdx] ?? []
    const rows = values.slice(headerIdx + 1)
    return { headers, rows }
  }

  async listOrders(): Promise<Order[]> {
    const { headers, rows } = await this.loadRaw()
    return rows
      .map((row, i) => rowToOrder(headers, row, this.mapping, this.headerRow + i + 1))
      .filter((o) => o.orderNumber)
  }

  async findOrderByNumber(orderNumber: string): Promise<Order | undefined> {
    const orders = await this.listOrders()
    return orders.find((o) => o.orderNumber === orderNumber)
  }

  async createOrder(order: Order): Promise<Order> {
    const { headers } = await this.loadRaw()
    const row = headers.map((h) => {
      const field = Object.keys(this.mapping).find((f) => this.mapping[f] === h)
      if (!field) return ""
      return orderFieldValue(order, field)
    })
    await withRetry(() => appendRow(this.spreadsheetId, this.tab, row))
    return order
  }

  async updateOrder(orderNumber: string, patch: Partial<Order>): Promise<Order> {
    const existing = await this.findOrderByNumber(orderNumber)
    if (!existing || !existing.rowIndex) throw new Error(`الطلب ${orderNumber} غير موجود في الشيت`)
    const merged = { ...existing, ...patch, updatedAt: new Date().toISOString() }
    const { headers } = await this.loadRaw()

    // Only write cells for fields that are actually present in patch, targeting exact columns.
    const updates: { column: string; value: string }[] = []
    for (const field of Object.keys(patch)) {
      const header = this.mapping[field]
      if (!header) continue
      const idx = headers.indexOf(header)
      if (idx === -1) continue
      updates.push({ column: columnLetter(idx), value: orderFieldValue(merged, field) })
    }
    // Status is derived, always keep in sync when status changes
    if (patch.status && this.mapping.status) {
      const idx = headers.indexOf(this.mapping.status)
      if (idx >= 0) updates.push({ column: columnLetter(idx), value: STATUS_CODE_TO_LABEL[merged.status] })
    }

    if (updates.length > 0) {
      await withRetry(() => updateRowCells(this.spreadsheetId, this.tab, existing.rowIndex!, updates))
    }
    return merged
  }

  async describeSource() {
    return { kind: "GOOGLE_SHEETS" as const, label: `Google Sheets: ${this.tab}` }
  }
}

function orderFieldValue(order: Order, field: string): string {
  switch (field) {
    case "orderNumber":
      return order.orderNumber
    case "orderDate":
      return order.orderDate
    case "customerName":
      return order.customerName
    case "phone":
      return order.phoneRaw || order.phoneNormalized
    case "wilaya":
      return order.wilaya
    case "commune":
      return order.commune
    case "address":
      return order.address ?? ""
    case "product":
      return order.productSummary
    case "quantity":
      return String(order.quantity)
    case "unitPrice":
      return String(order.lines[0]?.unitPrice ?? "")
    case "deliveryType":
      return order.deliveryType === "STOP_DESK" ? "مكتب" : "منزل"
    case "shippingFee":
      return String(order.shippingFee)
    case "total":
      return String(order.total)
    case "status":
      return STATUS_CODE_TO_LABEL[order.status] ?? order.status
    case "callAttempts":
      return String(order.callAttempts)
    case "postponedUntil":
      return order.postponedUntil ?? ""
    case "confirmationDate":
      return order.confirmationDate ?? ""
    case "notes":
      return order.notes ?? ""
    case "trackingNumber":
      return order.trackingNumber ?? ""
    case "deliveryResult":
      return order.deliveryResult ?? ""
    case "deliveryNotes":
      return order.deliveryNotes ?? ""
    case "source":
      return order.source ?? ""
    case "ttclid":
      return order.attribution.ttclid ?? ""
    case "ttp":
      return order.attribution.ttp ?? ""
    case "fbclid":
      return order.attribution.fbclid ?? ""
    case "campaign":
      return order.attribution.campaign ?? ""
    default:
      return ""
  }
}
