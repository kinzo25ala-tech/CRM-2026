import "server-only"
import { google } from "googleapis"

// Derive the auth type from googleapis' own re-export rather than importing a
// separately-versioned `google-auth-library` package directly — googleapis pins
// its own internal copy, and importing the top-level package can resolve to a
// different (incompatible) major version in the dependency tree.
type GoogleAuth = InstanceType<typeof google.auth.GoogleAuth>

// Server-only Google Sheets client. Credentials come exclusively from server-side
// environment variables and are NEVER exposed to the browser or written into any sheet.
//
// Required env vars (set later by the Owner):
//   GOOGLE_SERVICE_ACCOUNT_EMAIL
//   GOOGLE_SERVICE_ACCOUNT_PRIVATE_KEY  (with literal \n for newlines)
// Optional:
//   CRM_CONFIG_SPREADSHEET_ID  - bootstrap spreadsheet that hosts CRM_* config/support sheets

export function hasGoogleCredentials(): boolean {
  return Boolean(process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL && process.env.GOOGLE_SERVICE_ACCOUNT_PRIVATE_KEY)
}

let cachedAuth: GoogleAuth | null = null

function getAuth(): GoogleAuth {
  if (cachedAuth) return cachedAuth
  const email = process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL
  const key = process.env.GOOGLE_SERVICE_ACCOUNT_PRIVATE_KEY
  if (!email || !key) {
    throw new Error("لم يتم تكوين بيانات اعتماد Google. يرجى إضافة حساب الخدمة في الإعدادات.")
  }
  cachedAuth = new google.auth.GoogleAuth({
    credentials: {
      client_email: email,
      private_key: key.replace(/\\n/g, "\n"),
    },
    scopes: ["https://www.googleapis.com/auth/spreadsheets"],
  })
  return cachedAuth
}

export async function getSheetsClient() {
  const auth = getAuth()
  return google.sheets({ version: "v4", auth })
}

export function extractSpreadsheetId(urlOrId: string): string {
  const match = urlOrId.match(/spreadsheets\/d\/([a-zA-Z0-9-_]+)/)
  return match ? match[1] : urlOrId.trim()
}

export async function testConnection(spreadsheetId: string): Promise<{ ok: boolean; title?: string; error?: string }> {
  try {
    const sheets = await getSheetsClient()
    const res = await sheets.spreadsheets.get({ spreadsheetId })
    return { ok: true, title: res.data.properties?.title ?? undefined }
  } catch (err) {
    return { ok: false, error: mapGoogleError(err) }
  }
}

export async function listTabs(spreadsheetId: string): Promise<string[]> {
  const sheets = await getSheetsClient()
  const res = await sheets.spreadsheets.get({ spreadsheetId })
  return (res.data.sheets ?? []).map((s) => s.properties?.title ?? "").filter(Boolean)
}

export async function readTabValues(spreadsheetId: string, tab: string, range = ""): Promise<string[][]> {
  const sheets = await getSheetsClient()
  const fullRange = range ? `${tab}!${range}` : tab
  const res = await sheets.spreadsheets.values.get({ spreadsheetId, range: fullRange })
  return (res.data.values ?? []) as string[][]
}

/** Update a single row's specific columns without touching the rest of the row/sheet. */
export async function updateRowCells(
  spreadsheetId: string,
  tab: string,
  rowIndex: number, // 1-based sheet row
  updates: { column: string; value: string }[],
) {
  const sheets = await getSheetsClient()
  await sheets.spreadsheets.values.batchUpdate({
    spreadsheetId,
    requestBody: {
      valueInputOption: "USER_ENTERED",
      data: updates.map((u) => ({
        range: `${tab}!${u.column}${rowIndex}`,
        values: [[u.value]],
      })),
    },
  })
}

export async function appendRow(spreadsheetId: string, tab: string, row: string[]) {
  const sheets = await getSheetsClient()
  await sheets.spreadsheets.values.append({
    spreadsheetId,
    range: tab,
    valueInputOption: "USER_ENTERED",
    insertDataOption: "INSERT_ROWS",
    requestBody: { values: [row] },
  })
}

async function withRetry<T>(fn: () => Promise<T>, retries = 3): Promise<T> {
  let lastErr: unknown
  for (let i = 0; i < retries; i++) {
    try {
      return await fn()
    } catch (err: any) {
      lastErr = err
      const status = err?.code || err?.response?.status
      if (status === 429 || (status >= 500 && status < 600)) {
        await new Promise((r) => setTimeout(r, 500 * Math.pow(2, i)))
        continue
      }
      throw err
    }
  }
  throw lastErr
}

export { withRetry }

function mapGoogleError(err: unknown): string {
  const anyErr = err as any
  const status = anyErr?.code || anyErr?.response?.status
  if (status === 403) return "تم رفض الوصول إلى الشيت. تأكد من مشاركة الشيت مع حساب الخدمة."
  if (status === 404) return "لم يتم العثور على الشيت. تحقق من رابط أو رقم Spreadsheet."
  if (status === 429) return "تم تجاوز الحد المسموح من Google، حاول مرة أخرى بعد قليل."
  if (!hasGoogleCredentials()) return "لم يتم تكوين بيانات اعتماد Google بعد."
  return anyErr?.message || "حدث خطأ غير متوقع عند الاتصال بـ Google Sheets."
}
