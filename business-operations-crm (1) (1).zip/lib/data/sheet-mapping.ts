import type { ColumnMapping } from "@/lib/domain/types"

// CRM fields we need mapped to source header names. Header matching is done by
// normalized header text (Arabic/English synonyms), never by column position,
// so column reordering in the source sheet never breaks the mapping.
export const CRM_ORDER_FIELDS = [
  "orderNumber",
  "orderDate",
  "customerName",
  "phone",
  "wilaya",
  "commune",
  "address",
  "product",
  "quantity",
  "unitPrice",
  "deliveryType",
  "shippingFee",
  "total",
  "status",
  "callAttempts",
  "postponedUntil",
  "confirmationDate",
  "notes",
  "trackingNumber",
  "deliveryResult",
  "deliveryNotes",
  "source",
  "ttclid",
  "ttp",
  "fbclid",
  "campaign",
] as const

export type CrmOrderField = (typeof CRM_ORDER_FIELDS)[number]

const SYNONYMS: Record<CrmOrderField, string[]> = {
  orderNumber: ["order number", "order id", "رقم الطلب", "رقم الطلبية", "order#"],
  orderDate: ["order date", "date", "تاريخ الطلب", "التاريخ"],
  customerName: ["customer", "customer name", "name", "العميل", "اسم العميل", "الاسم"],
  phone: ["phone", "phone number", "الهاتف", "رقم الهاتف", "الجوال"],
  wilaya: ["wilaya", "state", "الولاية"],
  commune: ["commune", "city", "البلدية", "المدينة"],
  address: ["address", "العنوان"],
  product: ["product", "products", "المنتج", "المنتجات"],
  quantity: ["quantity", "qty", "الكمية"],
  unitPrice: ["unit price", "price", "سعر الوحدة", "السعر"],
  deliveryType: ["delivery type", "shipping type", "نوع التوصيل"],
  shippingFee: ["shipping fee", "delivery fee", "رسوم التوصيل", "سعر التوصيل"],
  total: ["total", "الإجمالي", "المجموع"],
  status: ["status", "confirmation", "الحالة", "التأكيد"],
  callAttempts: ["call attempts", "attempts", "محاولات الاتصال"],
  postponedUntil: ["postponed", "postponement", "التأجيل", "مؤجل الى"],
  confirmationDate: ["confirmation date", "تاريخ التأكيد"],
  notes: ["notes", "note", "ملاحظات"],
  trackingNumber: ["tracking number", "tracking", "رقم التتبع"],
  deliveryResult: ["delivery result", "نتيجة التوصيل"],
  deliveryNotes: ["delivery notes", "ملاحظات التوصيل"],
  source: ["source", "المصدر"],
  ttclid: ["ttclid"],
  ttp: ["ttp"],
  fbclid: ["fbclid"],
  campaign: ["campaign", "ad", "creative", "الحملة"],
}

function normalizeHeader(h: string): string {
  return h.trim().toLowerCase().replace(/\s+/g, " ")
}

export interface AutoMappingResult {
  mapping: ColumnMapping
  unmatched: CrmOrderField[]
  ambiguous: { field: CrmOrderField; candidates: string[] }[]
  unknownHeaders: string[]
}

export function autoMapHeaders(headers: string[]): AutoMappingResult {
  const mapping: ColumnMapping = {}
  const unmatched: CrmOrderField[] = []
  const ambiguous: { field: CrmOrderField; candidates: string[] }[] = []
  const usedHeaders = new Set<string>()

  for (const field of CRM_ORDER_FIELDS) {
    const synonyms = SYNONYMS[field].map(normalizeHeader)
    const candidates = headers.filter((h) => synonyms.includes(normalizeHeader(h)))
    if (candidates.length === 1) {
      mapping[field] = candidates[0]
      usedHeaders.add(candidates[0])
    } else if (candidates.length > 1) {
      ambiguous.push({ field, candidates })
      mapping[field] = candidates[0]
      usedHeaders.add(candidates[0])
    } else {
      unmatched.push(field)
    }
  }

  const unknownHeaders = headers.filter((h) => !usedHeaders.has(h))

  return { mapping, unmatched, ambiguous, unknownHeaders }
}

export function validateMapping(mapping: ColumnMapping): { valid: boolean; missing: CrmOrderField[] } {
  const required: CrmOrderField[] = ["orderNumber", "customerName", "phone", "product", "quantity", "total"]
  const missing = required.filter((f) => !mapping[f])
  return { valid: missing.length === 0, missing }
}
