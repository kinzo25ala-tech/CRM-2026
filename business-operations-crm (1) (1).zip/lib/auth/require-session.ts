import "server-only"
import { redirect } from "next/navigation"
import { getSession, type SessionPayload } from "@/lib/auth/session"
import { roleHasPermission, type Permission } from "@/lib/auth/permissions"

/** For use in Server Components / layouts. Redirects to /login when not authenticated. */
export async function requireSessionOrRedirect(): Promise<SessionPayload> {
  const session = await getSession()
  if (!session) redirect("/login")
  return session
}

/** Redirects to /dashboard (with an access-denied marker) when the session lacks the permission. */
export async function requirePermissionOrRedirect(permission: Permission): Promise<SessionPayload> {
  const session = await requireSessionOrRedirect()
  if (!roleHasPermission(session.role, permission)) {
    redirect("/dashboard?denied=1")
  }
  return session
}
