import "server-only"
import { cookies } from "next/headers"
import { createHmac, timingSafeEqual } from "crypto"
import type { Role } from "@/lib/domain/types"

const COOKIE_NAME = "crm_session"
const MAX_AGE_SECONDS = 60 * 60 * 24 * 7 // 7 days

function getSecret(): string {
  return process.env.CRM_SESSION_SECRET || "dev-only-insecure-secret-change-me"
}

export interface SessionPayload {
  userId: string
  username: string
  name: string
  role: Role
  issuedAt: number
}

function sign(payload: string): string {
  return createHmac("sha256", getSecret()).update(payload).digest("hex")
}

function encode(payload: SessionPayload): string {
  const json = JSON.stringify(payload)
  const body = Buffer.from(json, "utf-8").toString("base64url")
  const sig = sign(body)
  return `${body}.${sig}`
}

function decode(token: string): SessionPayload | null {
  const [body, sig] = token.split(".")
  if (!body || !sig) return null
  const expected = sign(body)
  try {
    const a = Buffer.from(sig)
    const b = Buffer.from(expected)
    if (a.length !== b.length || !timingSafeEqual(a, b)) return null
  } catch {
    return null
  }
  try {
    const json = Buffer.from(body, "base64url").toString("utf-8")
    return JSON.parse(json) as SessionPayload
  } catch {
    return null
  }
}

export async function createSession(payload: Omit<SessionPayload, "issuedAt">) {
  const store = await cookies()
  const token = encode({ ...payload, issuedAt: Date.now() })
  store.set(COOKIE_NAME, token, {
    httpOnly: true,
    secure: true,
    sameSite: "lax",
    path: "/",
    maxAge: MAX_AGE_SECONDS,
  })
}

export async function getSession(): Promise<SessionPayload | null> {
  const store = await cookies()
  const token = store.get(COOKIE_NAME)?.value
  if (!token) return null
  const payload = decode(token)
  if (!payload) return null
  if (Date.now() - payload.issuedAt > MAX_AGE_SECONDS * 1000) return null
  return payload
}

export async function destroySession() {
  const store = await cookies()
  store.delete(COOKIE_NAME)
}
