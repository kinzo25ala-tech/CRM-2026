import type { Role } from "@/lib/domain/types"

export type Permission =
  | "dashboard.view"
  | "orders.view"
  | "orders.edit"
  | "confirmation.view"
  | "confirmation.act"
  | "customers.view"
  | "customers.edit"
  | "products.view"
  | "products.edit"
  | "inventory.view"
  | "inventory.edit"
  | "shipping.view"
  | "shipping.edit"
  | "reports.view"
  | "settings.view"
  | "settings.users.manage"
  | "settings.datasources.manage"
  | "settings.tiktok.manage"
  | "settings.audit.view"

const ROLE_PERMISSIONS: Record<Role, Permission[]> = {
  OWNER: [
    "dashboard.view",
    "orders.view",
    "orders.edit",
    "confirmation.view",
    "confirmation.act",
    "customers.view",
    "customers.edit",
    "products.view",
    "products.edit",
    "inventory.view",
    "inventory.edit",
    "shipping.view",
    "shipping.edit",
    "reports.view",
    "settings.view",
    "settings.users.manage",
    "settings.datasources.manage",
    "settings.tiktok.manage",
    "settings.audit.view",
  ],
  MANAGER: [
    "dashboard.view",
    "orders.view",
    "orders.edit",
    "confirmation.view",
    "confirmation.act",
    "customers.view",
    "customers.edit",
    "products.view",
    "products.edit",
    "inventory.view",
    "inventory.edit",
    "shipping.view",
    "shipping.edit",
    "reports.view",
    "settings.view",
  ],
  CONFIRMATION_AGENT: ["confirmation.view", "confirmation.act", "orders.view", "customers.view"],
  SHIPPING_AGENT: ["shipping.view", "shipping.edit", "orders.view"],
  VIEWER: ["dashboard.view", "orders.view", "customers.view", "products.view", "reports.view"],
}

export function roleHasPermission(role: Role, permission: Permission): boolean {
  return ROLE_PERMISSIONS[role]?.includes(permission) ?? false
}

export function assertPermission(role: Role, permission: Permission) {
  if (!roleHasPermission(role, permission)) {
    throw new Error("لا تملك صلاحية الوصول إلى هذه العملية")
  }
}

export const ROLE_LABELS_AR: Record<Role, string> = {
  OWNER: "المالك",
  MANAGER: "مدير",
  CONFIRMATION_AGENT: "موظف تأكيد",
  SHIPPING_AGENT: "موظف شحن",
  VIEWER: "مشاهد",
}

export const NAV_PERMISSION: Record<string, Permission> = {
  "/dashboard": "dashboard.view",
  "/orders": "orders.view",
  "/confirmation": "confirmation.view",
  "/customers": "customers.view",
  "/products": "products.view",
  "/inventory": "inventory.view",
  "/shipping": "shipping.view",
  "/reports": "reports.view",
  "/settings": "settings.view",
}
