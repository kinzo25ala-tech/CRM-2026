import "server-only"
import { randomUUID } from "crypto"
import { mutateStore, readStore } from "@/lib/data/json-store"
import { hashPassword } from "@/lib/auth/password"
// hashPassword returns { hash, salt } — CrmUser expects { passwordHash, passwordSalt }.
function toPasswordFields({ hash, salt }: { hash: string; salt: string }) {
  return { passwordHash: hash, passwordSalt: salt }
}
import type { CrmUser, Role } from "@/lib/domain/types"

const STORE_NAME = "CRM_Users"

async function seedIfEmpty(): Promise<CrmUser[]> {
  return mutateStore<CrmUser[]>(STORE_NAME, [], (users) => {
    if (users.length > 0) return users
    const owner: CrmUser = {
      id: randomUUID(),
      username: "admin",
      name: "المالك",
      role: "OWNER",
      ...toPasswordFields(hashPassword("admin123")),
      active: true,
      createdAt: new Date().toISOString(),
    }
    const agent: CrmUser = {
      id: randomUUID(),
      username: "agent",
      name: "موظف التأكيد",
      role: "CONFIRMATION_AGENT",
      ...toPasswordFields(hashPassword("agent123")),
      active: true,
      createdAt: new Date().toISOString(),
    }
    return [owner, agent]
  })
}

export async function listUsers(): Promise<CrmUser[]> {
  await seedIfEmpty()
  return readStore<CrmUser[]>(STORE_NAME, [])
}

export async function findUserByUsername(username: string): Promise<CrmUser | undefined> {
  const users = await listUsers()
  return users.find((u) => u.username.toLowerCase() === username.toLowerCase())
}

export async function createUser(input: { username: string; name: string; role: Role; password: string }) {
  return mutateStore<CrmUser[]>(STORE_NAME, [], (users) => {
    if (users.some((u) => u.username.toLowerCase() === input.username.toLowerCase())) {
      throw new Error("اسم المستخدم موجود مسبقاً")
    }
    const user: CrmUser = {
      id: randomUUID(),
      username: input.username,
      name: input.name,
      role: input.role,
      ...toPasswordFields(hashPassword(input.password)),
      active: true,
      createdAt: new Date().toISOString(),
    }
    return [...users, user]
  })
}

export async function setUserActive(id: string, active: boolean) {
  return mutateStore<CrmUser[]>(STORE_NAME, [], (users) => users.map((u) => (u.id === id ? { ...u, active } : u)))
}

export async function updateUserRole(id: string, role: Role) {
  return mutateStore<CrmUser[]>(STORE_NAME, [], (users) => users.map((u) => (u.id === id ? { ...u, role } : u)))
}
