import "server-only"
import { readTabValues, testConnection as testGoogleConnection, listTabs as listGoogleTabs } from "@/lib/data/google-sheets-client"
import { rowToOrder } from "@/lib/data/google-sheets-repository"
import { autoMapHeaders, validateMapping } from "@/lib/data/sheet-mapping"
import { getConnection, updateConnection } from "@/lib/data/connection-store"
import { localRepository } from "@/lib/data/local-repository"
import { recordAudit } from "@/lib/services/audit-service"
import type { SyncResult } from "@/lib/domain/types"

export async function testConnectionById(connectionId: string) {
  const conn = await getConnection(connectionId)
  if (!conn) throw new Error("الاتصال غير موجود")
  return testGoogleConnection(conn.spreadsheetId)
}

export async function listTabsForConnection(connectionId: string) {
  const conn = await getConnection(connectionId)
  if (!conn) throw new Error("الاتصال غير موجود")
  return listGoogleTabs(conn.spreadsheetId)
}

export async function readHeadersAndAutoMap(connectionId: string, tab: string, headerRow = 1) {
  const conn = await getConnection(connectionId)
  if (!conn) throw new Error("الاتصال غير موجود")
  const values = await readTabValues(conn.spreadsheetId, tab)
  const headers = values[headerRow - 1] ?? []
  const auto = autoMapHeaders(headers)
  return { headers, ...auto }
}

async function loadSourceOrders(connectionId: string) {
  const conn = await getConnection(connectionId)
  if (!conn) throw new Error("الاتصال غير موجود")
  if (!conn.selectedOrdersTab) throw new Error("لم يتم اختيار تبويب الطلبات")
  const { valid, missing } = validateMapping(conn.mapping)
  if (!valid) throw new Error(`الربط غير مكتمل. حقول ناقصة: ${missing.join(", ")}`)

  const values = await readTabValues(conn.spreadsheetId, conn.selectedOrdersTab)
  const headerIdx = conn.headerRow - 1
  const headers = values[headerIdx] ?? []
  const rows = values.slice(headerIdx + 1)
  const orders = rows
    .map((row, i) => ({ row, order: rowToOrder(headers, row, conn.mapping, conn.headerRow + i + 1) }))
    .filter((r) => r.order.orderNumber)
  return { conn, orders }
}

/** PREVIEW: read, map, validate, detect duplicates, summarize. Writes nothing. */
export async function previewSync(connectionId: string): Promise<SyncResult> {
  const startedAt = new Date().toISOString()
  const { orders } = await loadSourceOrders(connectionId)

  const seen = new Map<string, number[]>()
  const errors: SyncResult["errors"] = []
  for (const { order } of orders) {
    if (!order.orderNumber) continue
    const list = seen.get(order.orderNumber) ?? []
    list.push(order.rowIndex ?? 0)
    seen.set(order.orderNumber, list)
    if (!order.phoneNormalized) {
      errors.push({ row: order.rowIndex ?? 0, message: `رقم هاتف غير صالح للطلب ${order.orderNumber}` })
    }
  }
  const duplicates = [...seen.entries()]
    .filter(([, rows]) => rows.length > 1)
    .map(([orderNumber, rows]) => ({ orderNumber, rows }))

  const existing = await localRepository.listOrders()
  const existingNumbers = new Set(existing.map((o) => o.orderNumber))
  const created = orders.filter((o) => !existingNumbers.has(o.order.orderNumber)).length
  const updated = orders.filter((o) => existingNumbers.has(o.order.orderNumber)).length

  return {
    mode: "PREVIEW",
    rowsScanned: orders.length,
    created,
    updated,
    skipped: 0,
    errors,
    duplicates,
    startedAt,
    finishedAt: new Date().toISOString(),
  }
}

function ordersDiffer(a: Record<string, unknown>, b: Record<string, unknown>, fields: string[]) {
  return fields.some((f) => JSON.stringify(a[f]) !== JSON.stringify(b[f]))
}

/** FULL SYNC: actually creates/updates real CRM order records, one at a time, by stable order number. */
export async function runFullSync(connectionId: string, actor: string): Promise<SyncResult> {
  const startedAt = new Date().toISOString()
  const { conn, orders } = await loadSourceOrders(connectionId)

  let created = 0
  let updated = 0
  let skipped = 0
  const errors: SyncResult["errors"] = []
  const seen = new Set<string>()
  const duplicateRows = new Map<string, number[]>()

  const compareFields = ["status", "customerName", "phoneNormalized", "total", "notes", "trackingNumber"]

  for (const { order } of orders) {
    try {
      if (!order.orderNumber) {
        errors.push({ row: order.rowIndex ?? 0, message: "رقم الطلب مفقود، تم تجاهل الصف" })
        continue
      }
      if (seen.has(order.orderNumber)) {
        const rows = duplicateRows.get(order.orderNumber) ?? []
        rows.push(order.rowIndex ?? 0)
        duplicateRows.set(order.orderNumber, rows)
        skipped++
        continue
      }
      seen.add(order.orderNumber)

      const existing = await localRepository.findOrderByNumber(order.orderNumber)
      if (!existing) {
        await localRepository.createOrder(order)
        created++
      } else if (ordersDiffer(existing as any, order as any, compareFields)) {
        await localRepository.updateOrder(order.orderNumber, order)
        updated++
      } else {
        skipped++
      }
    } catch (err) {
      errors.push({ row: order.rowIndex ?? 0, message: err instanceof Error ? err.message : "خطأ غير معروف" })
    }
  }

  const result: SyncResult = {
    mode: "FULL",
    rowsScanned: orders.length,
    created,
    updated,
    skipped,
    errors,
    duplicates: [...duplicateRows.entries()].map(([orderNumber, rows]) => ({ orderNumber, rows })),
    startedAt,
    finishedAt: new Date().toISOString(),
  }

  await updateConnection(conn.connectionId, {
    lastSyncAt: result.finishedAt,
    lastSyncStatus: errors.length > 0 && created === 0 && updated === 0 ? "ERROR" : "SUCCESS",
    lastSyncSummary: `تم إنشاء ${created}، تحديث ${updated}، تجاهل ${skipped}، أخطاء ${errors.length}`,
  })

  await recordAudit(actor, "SYNC_FULL", "connection", conn.connectionId, result.lastSyncSummary)

  return result
}
